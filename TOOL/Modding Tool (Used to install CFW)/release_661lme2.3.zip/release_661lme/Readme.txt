LCFW 6.61 LME installer for OFW 6.61

-- What is this? -- 
This is LCFW for OFW 6.61.

The degree of stability is still unknown. 
Please test it on your own and refer to different people's test reports.

-- How to use --
Copy "installer" folder and "launcher" folder at "ms0:/PSP/GAME/"

-- Preparation --
First. You need to install LCFW modules in your PSP.

1.Execute "LME Installer for 6.61" from XMB.
2.You can select these action:
Press x to install LCFW.
Press [] to uninstall LCFW.
Press R to exit.

After the action, PSP will rboot.

-- Start LCFW --
1.Execute "LME Launcher for 6.61" from XMB.
2. enjoy :)

-- How to enter RecoveryMenu? --
From XMB :Open VshMenu and select "Enter Recovery ->"
From LCFW:Execute Launcher again.
From OFW :Execute Launcher with hold "R".

-- How to mount UmdVideo? --
0. Enable UmdVideo option at RecoveryMenu->config->Use UmdVideo Patch (Go only).
1. copy Iso file at ms(ef)0:/ISO/VIDEO/ .
2. Open VshMenu and select Iso file name.

-- Credit --
some1/Davee/Proxima/Zecoxao: For their kxploit.
liquidzigong	: For his 639kxploit POC.
bbtgp			: For his PrxEncrypter.
Draan			: For his kirk-engine code.
J416			: For his rebootex sample.
N-zaki			: For providing PSPGo from him.
Moz				: For his beta test and translated language file in Italian.
BombingBasta	: For his translated language file in French.
Rapper_skull	: For his translated language file in Italian.
The Z			: For his translated language file in German.
largeroliker	: For his translated language file in Spanish.
bassiw			: For his translated language file in Netherlands.
Publikacii		: For his translated language file in Bulgarian.
Yoti			: For his translated language file in Russian.
ExzoTikFruiT	: For his translated language file in Russian.
ABCanG &Dadrfy &estuibal &plum &SnyFbSx &teck4 &wn : For their work to collect nid list.
Tipped OuT		: For his EBOOT.PBP ICON0.

Thanks to: josemetallica, Xeeynamo, theastamana, GovanifY, Reidenshi
for helping in translating Recovery and VshMenu.

-- About translating the recovery menu --
To translate the recovery, create a text file in ms0:/seplugins/xx_recovery.txt or flash1:/xx_recovery.txt
To translate the VshMenu, create a text file in ms0:/seplugins/xx_vshmenu.txt or flash1:/xx_vshmenu.txt
"xx" is the language code of your language.

es -> spanish
en -> english
fr -> french
de -> german
it -> italian
ja -> japanese
ko -> korean
nl -> netherlands
pt -> portuguese
ru -> russian
ch1 -> chinese simplified
ch2 -> chinese traditional

To use custom font in RecoveryMenu and VshMenu, put font data at ms0:/seplugins/xx_ftable.bin or flash1:/xx_ftable.bin
"xx" is the language code of your language.
