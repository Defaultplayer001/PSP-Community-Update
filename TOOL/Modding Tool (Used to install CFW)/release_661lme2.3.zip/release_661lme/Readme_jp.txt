-- 何これ？--
FW6.61向けのLCFWです。

注意
このツールを使って何か不具合が出ても自己責任でお願いします。製作者は一切責任をとりません。

ｰｰファイルの説明

- installer (XMBでの表示名は "LME Installer for 6.61")
flash0に必要なファイルを書き込むツールです。アンインストールもできます。

- launcher (XMBでの表示名は "LME Launcher for 6.61" )
LCFWを起動するツールです。
上の installer で必要なモジュールを書き込んでいないと起動しません。


使い方。

1, OFW6.61でinstallerを起動してしばらく待つ。
2,
Press X to install modules
Press [] to uninstall modules
R to exit

と表示されるはずなので、インストールする場合は　Xを、
アンインストールする場合は　[]（四角)を押してください。
Rを押すと何もしないで終了します。

------ここから下はインストールを選んだ人向けの説明です。--------
3, PSPが再起動してXMBに戻るはずです。この状態ではまだOFWのままです。
4, XMBから launcher を起動します。
5, 自動的ににXMBに戻ります。これでLCFWが適用状態になっているはずです。

一度インストールしてしまえば、次回からはlauncherの起動のみでおｋです。

-- リカバリーモードに入るには？　--
XMBから　:VshMenuで　EnterRecovery-> を選択。
LCFWから：もう一度launcherを起動してください。
OFWから：Rを押しながらlauncherを起動してください。

-- UmdVideo のマウント --
0. RecoveryMenu->config->Use UmdVideo Patch の設定を有効にしてください(Go だけ).
1. ms(ef)0:/ISO/VIDEO/ にIsoをコピー.
2. VshMenu からマウントするIsoを選択.

-- Credit --
some1/Davee/Proxima/Zecoxao: For their kxploit.
liquidzigong	: For his 639kxploit POC.
bbtgp			: For his PrxEncrypter.
Draan			: For his kirk-engine code.
J416			: For his rebootex sample.
N-zaki			: For providing PSPGo from him.
Moz				: For his beta test and translated language file in Italian.
BombingBasta	: For his translated language file in French.
Rapper_skull	: For his translated language file in Italian.
The Z			: For his translated language file in German.
largeroliker	: For his translated language file in Spanish.
bassiw			: For his translated language file in Netherlands.
Publikacii		: For his translated language file in Bulgarian.
Yoti			: For his translated language file in Russian.
ExzoTikFruiT	: For his translated language file in Russian.
ABCanG &Dadrfy &estuibal &plum &SnyFbSx &teck4 &wn : For their work to collect nid list.
Tipped OuT		: For his EBOOT.PBP ICON0.

Thanks to: josemetallica, Xeeynamo, theastamana, GovanifY, Reidenshi
for helping in translating Recovery and VshMenu.

-- RecoveryMenuのカスタムフォントとTxtについて--
ms0:/seplugins/xx_recovery.txt か flash1:/xx_recovery.txtに言語TXTファイルを置けばそれを読み込む仕様です。
"xx" に入るのが以下の言語コードです。

es -> spanish
en -> english
fr -> french
de -> german
it -> italian
ja -> japanese
ko -> korean
nl -> netherlands
pt -> portuguese
ru -> russian
ch1 -> chinese simplified
ch2 -> chinese traditional

VshMenuの場合のファイル名は　xx_vshmenu.txt です。
フォントのパスはms0:/seplugins/xx_ftable.binです。
