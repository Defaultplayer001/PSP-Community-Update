PSP Filer versi�n 6.6

/* Please donate (only U.S. $10), if you feel Filer useful.
Paypal & credit card will be accepted. */
http://www.geocities.jp/mediumgauge/

<ADVERTENCIA>
�selo BAJO SU RESPONSABILIDAD!!!.

<RECLAMO>
Este software puede causar da�os importantes a la memoria interna de tu PSP por falta de conocimiento
o por fallos que el propio programa pueda tener.
El creador del software no se har� responsable de cualquier da�o que puedas causar.
Si haces un brick a tu PSP es �nicamente culpa tuya.
(puedes enviar fallos a mediumgauge@yahoo.co.jp, y podr�an solucionarse en futuras versiones)

- Este software utiliza la fuente "shinonome"
- Para visualizar im�genes PNG, se utiliza libpng1.2.8 + zlib
- Para visualizar im�genes JPG, se utiliza la librer�a jpeg-6b

<Uso del PSPFiler/Ayuda>
SELECT:
 mostrar ayuda
   circulo: cambiar idioma (Japon�s, Ingl�s, Espa�ol, Portugu�s, Alem�n)
   cuadrado: guardar configuraci�n

START:
 mover al siguiente dispositivo. (MS0 > UMD > flash0 > flash1 > RAMDISK)

DIGITAL ARRIBA y ABAJO:
 mover cursor

ANAL�GICO ARRIBA y ABAJO:
 mover cursor (m�s r�pido)

DIGITAL IZQUIERDA:
 desmarcar todos los archivos de la carpeta actual.

DIGITAL DERECHA:
 marcar todos los archivos de la carpeta actual.

ANAl�GICO IZQUIERDA:
 desmarcar todos los archivos de la carpeta actual y de sus subcarpetas.

ANAL�GICO DERECHA:
 marcar todos los archivos de la carpeta actual y de sus subcarpetas.

CUADRADO:
 marcar archivo actual

C�RCULO:
 contraer/expandir carpeta
 visualizar imagen .jpg / .jpeg / .bmp /.png
 reproducir .wav / .mp3
 mostrar archivo (en otros casos)

TRI�NGULO: men� del programa
   c�rculo: sintonizador musical
   cuadrado: visor de memoria
    puedes ver la memoria principal, la VRAM y el portapapeles.
    nota: esta funci�n necesita bater�a porque lee la memoria de cada frame.
     no dejes sola la PSP leyendo la memoria.
   tri�ngulo: alternar entre mostrar o no el fondo de pantalla (si se utiliza)
   R: ripeado del lector UMD
    PSPFiler ripea un disco UMD a una imagen en la carpeta ms0:/iso/
    si la carpeta /iso/ no existe, se crea autom�ticamente.
    si la MS est� llena, cambia la MS y PSPFiler continuar� ripeando.
    al finalizar, c�piate todos los archivos creados en cada una de las MS (nombrados *.1, *.2, ...etc) a cualquier carpeta de tu PC, y utiliza el "cat.bat" creado en la �ltima parte del ripeo, y as� tendr�s una imagen ISO completa.
   L: mantenimiento de memoria flash
    PSPFiler hace copia de seguridad de flash0/flash1 en la MS.
    y, en MODO HACKER, PSPFiler puede restaurar esas copias de seguridad de flash0/flash1 desde la MS.
    Puedes usar esta funci�n para recuperar copias de seguridad de tu flash.
    Al finalizar la recuperaci�n, la PSP no reconocer� los archivos restaurados, as� que recomiendo que reinicies manualmente la consola (es un fallo de la PSP).
   arriba: conectar USB
    En esta versi�n, despu�s de desconectar, PSPFiler no puede leer los archivos del PC correctamente, as� que recomiendo reinsertar la MS tal y como pide el programa.
   derecha: cambiar los ajustes de color
    Puedes cambiar los ajustes de color y guardarlos pulsando c�rculo.

X: operaciones en archivos
   c�rculo: copiar/mover archivos
     en archivo marcado: copiar/mover todos los archivos marcados.
     en archivo sin marcar: copiar/mover ese archivo.
     en carpeta: copiar/mover todos los archivos & subcarpetas de esa carpeta.
     nota.1: cuando mueves archivos, solo hace 'copiar y borrar', sin embargo no se puede hacer si no hay suficiente espacio en la unidad actual.
     nota.2: no puedes modificar archivos de la flash0/flash1 hasta que no actives el MODO HACKER.
   cuadrado: eliminar archivos
     en archivo marcado: quitar todos los archivos marcados.
     en archivo desmarcado: eliminar ese archivo.
     en carpeta: eliminar todos los archivos y subcarpetas de esa carpeta.
   R: renombrar archivo
       renombrar archivo / carpeta actuales.
   L: crear nueva carpeta
   arriba: mostrar / editar informaci�n en la ra�z:
     muestra la info del dispositivo y comprueba la estructura de cl�ster.
     pulsa CIRCULO para mostrar informaci�n detallada.
     en archivo o carpeta:
      mostrar info de archivo/carpeta y editar atributos y fechas.
      estando en MODO HACKER tambi�n puedes editar archivos de flash0/flash1.

R: ordenar archivos de carpeta actual. (el orden de los archivos no se guardar�)
  cambios en el orden como sigue:
    por nombre(N) > por extensi�n(E) > por tama�o(S) > por fecha(D) >
    por menor tama�o(s) > por menor fecha(d) > sin ordenar
    
ANAL�GICO IZQUIERDA + R:
  activar/desactivar MODO HACKER.
  ATENCI�N: utiliza el MODO HACKER POR TU CUENTA (NO LO USES SI ERES NOVATO).

<controles visor textos/c�mo hacerlo>
ARRIBA y ABAJO: mover cursor
JOYSTICK ARRIBA y ABAJO: mover cursor (m�s r�pido)
IZQUIERDA y DERECHA: desplazamiento izquierdo y derecho (funciona en modo FLAT).
JOYSTICK IZQUIERDA y DERECHA: desplazamiento r�pido izquierdo y derecho (funciona en modo FLAT).
LR: (L) carga la p�gina anterior, (R) carga la p�gina siguiente.
TRI�NGULO: cambia la tabulaci�n 4/8 (el texto se recarga en modo BEND).
CUADRADO: pasar al visor binario.
CIRCULO: pasar de modo FLAT / modo BEND.
 modo FLAT: puedes desplazarte a izquierda y derecha para leer texto.
 modo BEND: todo el texto se reordena para que quepa en la pantalla.
 el texto se recarga cuando se cambia entre modo BEND y modo FLAT.
START: cambiar codificaci�n
SELECT: mostrar ayuda
X: volver a PSPFiler.

<uso del visor de im�genes>
JOYSTICK: desplazar imagen
R: disminuir imagen (menos zoom)
L: aumentar imagen (m�s zoom)
CIRCULO: cambiar el tama�o de la imagen a pantalla completa
CUADRADO: ir al modo binario
START + TRIANGULO: guardar imagen como fondo de pantalla
PAD DERECHA: ir a la siguiente imagen (de la carpeta actual)
PAD IZQUIERDA: ir a la anterior imagen (de la carpeta actual)
PAD ARRIBA y ABAJO: girar la imagen
X: volver al explorador de archivos

<trucos en las operaciones con archivos>
la mayor�a de las operaciones se hacen a trav�s de la RAMDISK.
La PSP tiene 24MB de memoria para el usuario, y podemos utilizar alrededor de 20MB para la RAMDISK.
Es por eso que no podemos copiar/pegar archivos demasiado grandes, y cuando se han copiado/pegado archivos grandes en la RAMDISK, PSPFiler no puede realizar las operaciones correctamente debido a la poca memoria libre.
Recuerda de eliminar los archivos que no utilices de la RAMDISK - s�lo es una unidad de almacenamiento temporal y no deber�as llenarla mucho.

<trucos para el fondo de pantalla>
- si colocas cualquiera de los archivos  wallpaper.bmp / wallpaper.jpg / wallpaper.png,(solo usa bmp,jpg o png), el programa PSPFiler lo detectar� como fondo de pantalla al arrancar el programa.
- en el visor de im�genes, pulsa START + TRIANGULO en la imagen que quieras y se guardar� como "wallpaper.bmp" y se pondr� como fondo de pantalla del programa.

<gracias a>
Gracias a djroman por la traducci�n al Espa�ol.
Gracias a Me'Katis por la traducci�n al Portugu�s.
Gracias a Experiment1106 por la traducci�n al Alem�n.
Gracias a ikari_kun por la traducci�n al Ruso.
Gracias a RaiderX por hacer el icono.
Gracias a clint, evilseph, moca, tuw y fergie por la ayuda en el debug.
Gracias a Daniel por corregir el Ingl�s.
