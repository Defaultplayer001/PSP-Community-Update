﻿PSP Filer version 6.6

/* Please donate (only U.S. $10), if you feel Filer useful.
Paypal & credit card will be accepted. */
http://www.geocities.jp/mediumgauge/

<ATENÇÃO!>
UTILIZE POR SUA PRÓPRIA CONTA E RISCO.

<DISCLAIMER>
Este software pode causar danos graves ao seu PSP causados pelo mau uso ou por possíveis bugs no próprio Filer.
O criador do PSP Filer não se fará responsável por qualquer dano que usuários causem a seus PSPs pelo mau uso deste programa.
Se você brickar seu PSP, a responsabilidade é total e somente sua.
(para reportar bugs envie uma mensagem o mais detalhada possível en inglês a mediumgauge@yahoo.co.jp, e este podera ser corrigido em futuras versões)

- este programa utiliza "shinonome font".
- para visualizar arquivos PNG, são usados libpng1.2.8 + zlib.
- para visualizar arquivos JPEG, é utilizada jpeg-6b library.

<Utilização/Controles do Filer>
SELECT:
 mostra a ajuda
  CIRCULO: muda a linguagem (Japonês, Inglês, Espanhol, Português, Alemão, Russo)
  QUADRADO: salva configurações

START:
 mover para o próximo dispositivo. (MS0 > UMD > flash0 > flash1 > RAMDISK)

DIGITAL PARA CIMA E PARA BAIXO:
 move o cursor

ANALÓGICO PARA CIMA E PARA BAIXO:
 move o cursor (rápido)

DIGITAL PARA A ESQUERDA:
 desmarkar todos os arquivos da pasta atual

DIGITAL PARA A DIREITA:
 marcar todos os arquivos da pasta atual

ANALÓGICO PARA A ESQUERDA:
 desmarcar todos os arquivos da pasta atual e suas sub-pastas

ANALÓGICO PARA A DIREITA:
 marcar todos os arquivos da pasta atual e suas sub-pastas

QUADRADO:
 marcar arquivo atual

CIRCULO:
 contrai/expande uma pasta
 visualiza imagens .jpg / .jpeg / .bmp / .png
 executa arquivos .wav / .mp3
 
TRIANGULO: menu do programa
  CIRCULO: sintonizador de tons
  QUADRADO: visualizaador de memória
   você poderá ver o conteúdo da memória principal, VRAM, e "scratch pad".
   nota: esta opção necessita bateria, pois efetua a leitura da memória a cada segundo.
    não deixe o PSP mostrando constantemente a memória.
  TRIÂNGULO: mudar modo de visualização do wallpaper (se estiver utilizando um wallpaper)
  R: Copiar dispositivo UMD
   Filer copia um UMD criando um imagem ISO na pasta ms0:/iso/
   se a pasta /iso/ não existir , ela será criada
   se o Memory Stick estiver cheio, mude de Memory Stick e o Filer continuará a cópia,
   e ao final, junte todas as partes criadas pelos Filer (nameadas *.1, *.2, ...etc) em uma única pasta no PC, e execute o arquivo "cat.bat" que será criado junto com a última parte, assim você terá uma ISO completa montada.
  L: manutanção da memória flash
   Filer cria cópias de backup de sua flash0/flash1 em forma de imagem .IMG na raiz do Memory Stick
   e, estando em HACKER MODE, Filer pode restaurar a flash0/flash1 utilizando as imgens previamente criadas e armazenadas no Memory Stick.
   você pode utilizar esta opção para efetuar uma recuperação das flashs, caso seja necessário.
   após efetuada a restauração, é recomendado sair do Filer e reiniciar o PSP, pois por culpa de um bug do próprio PSP, os novos arquivos não são reconhecidos sem este procedimento.
  ANALÓGICO PARA CIMA: conecta o USB
   nesta versão, após desconectar, o Filer não consegue ler corretamente os arquivos que foram modificados atravéz do PC, assim que é altamente recomendado que se retire e volte a inserir o Memory Stick no PSP quando requisitado pelo Filer, para que as mudanças tenham efeito.
  ANALÓGICO PARA A DIREITA: modificar as opções de cor
   você pode modificar todas as cores do Filer e depois salvar as configurações apertando CIRCULO

CRUZ (X): operações com arquivos
  CIRCULO: copiar/mover arquivos
    nos arquivos marcados: copia/move todos os arquivos marcados
    em arquivos não marcados: copia/move somente o arquivo selecionado
    na pasta: copia/move todos os arquivos e subpastas da atual pasta
    nota 1: quando você mover arquivos, o Filer executará um "copiar e deletar" com os arquivos, porém, a operação ão poderá ser efetuada se não houver espaço suficiente no dispositivo atual.
    nota 2: você não pode modificar nada na flash0/flash1 se não tiver antes ativdo o HACKER MODE.
  QUADRADO: deletar arquivos
    nos arquivos marcados: deleta todos os arquivos marcados
    em arquivos não marcados: deleta somente o arquivo selecionado
    na pasta: deleta todos os arquivos e subpastas da atual pasta
  R: renomear arquivos
    renomeia o atual arquivo/pasta
  L: criar nova pasta
  ANALÓGICO PARA CIMA: visualizar/editar informações do arquivo
    na pasta raiz:
      mostra informações do dispositivo atual e efetua uma checagem na estrutura de clusters
      pressione CIRCULO para visualizar informações mais detalhadas
    em pasta ou arquivor:
      mostra informações do arquivo/pasta e edita atributos e 'timestamp'
      com HACKER MODE ativado você pode também editar arquivos na flash0/flash1

R: organiza arquivos na pasta atual (esta operação não é salva)
 a ordem dos arquivos segue os seguintes padrões:
   por nome(N) > por extensão(E) > por tamanho(S) > por data(D) >
   pela menor tamanho(s) > pela data mais antiga(d) > não organizado

ANALÓGICO PARA A ESQUERDA + R:
 ativa HACKER MODE.
 aviso: utilize o HACKER MODE por sua própria conta e risco (NÃO UTILIZE ESTE MODO SE VOCÊ FOR UM NOOB!).

<Utilização/Controles do visualizador de texto>
DIGITAL PARA CIMA E PARA BAIXO: mover cursor
ANALÓGICO PARA CIMA E PARA BAIXO: mover cursor (rápido)
DIGITAL PARA ESQUERDA E DIREITA: mover para esquerda ou direita (funciona no modo FLAT)
ANALÓGICO PARA ESQUERDA E DIREITA: mover rápido para esquerda ou direita (funciona no modo FLAT)
L/R: mover de página (L para página anterior e R para próxima página)
TRIÂNGULO: muda a parada de tabulação entre 4 e 8 (o texto é recarregado quando em modo BEND)
QUADRADO: muda para o visualizador binario
CIRCULO: muda entre os modos FLAT e BEND
 modo FLAT : você pode mover para esquerda e direita para visualizar o texto.
 modo BEND : todos os textos são redimencionados para caberem na tela.
 os textos são recarregado quando este modo é mudado.
START: Muda a codificação do texto
SELECT: mostra a ajuda do visualizadro de textos
CRUZ (X): retorna ao Filer

<Utilização/Controles do visualizador binario>
DIGITAL PARA CIMA E PARA BAIXO: mover cursor
ANALÓGICO PARA CIMA E PARA BAIXO: mover cursor (rápido)
L/R: mover cursor por página
QUADRADO: retorna para o visualizador de texto/imagem
CRUZ (X): retorna ao Filer

<Utilização/Controles do visualizador de imagens>
ANALÓGICO: mover-se pela imagem
R: diminuir imagem (zoom out)
L: aumentar imagem (zoom in)
CIRCULO: muda o tamanho da imagem para caber na tela
QUADRADO: muda para o visualizador binário
START + TRIANGULO: salva a atual imagem como wallpaper
DIGITAL PARA A DIREITA: move para a próxima imagem (dentro da pasta atual)
DIGITAL PARA A ESQUERDA: move para a imagem anterior (dentro da pasta atual)
CRUZ (X): retorna ao Filer

<Dicas de operação de arquivos>
A maioria das operações com arquivos é feita atravéz da RAMDISK.
O PSP possui 24MB de memória para o usuário, e deste total, podemos utilizar cerca de 20MB para a RAMDISK.
Por este motivo, não é possível copiar/colar arquivos muito grandes, e, quando existem arquivos muito grandes na RAMDISK, o Filer não consegue completar algumas tarefas por culpa da pouca memória livre.
Lembre-se de não deixar arquivo grandes ou muitos arquivos na RAMDISK - Esta é apenas uma área de uso temporário, assim que é recomendável apagar qualquer arquivo desta área após ter finalizado as tarefas com tal/tais arquivo(s).

<Dicas para wallpapers>
- se você colocar uma imagem com o nome wallpaper.bmp / wallpaper.jpg / wallpaper.png, Filer utilizará esta imagem como wallpaper interno assim que o programa iniciar.
- no visualizador de imagens, apertando START + TRIANGULO, uma cópia da imagem que estiver sendo visualizada no momento será salva com o nome wallpaper.bmp, e esta imagem será utilizada como wallpaper interno do Filer.

<Agradecimentos>
Agradecimentos para djroman pela tradução para a língua espanhola.
Agradecimentos para Me'Katis pela tradução para a língua Portuguesa do Brasil.
Agradecimentos para Experiment1106 pela tradução para a língua Alemã.
Agradecimentos para RaiderX pela criação do novo ícone.
Agradecimentos para clint, evilseph, moca, tuw e ferge pela ajuda com o 'debugging'.
Agradecimentos para Daniel pelas correções na tradução em inglês.
