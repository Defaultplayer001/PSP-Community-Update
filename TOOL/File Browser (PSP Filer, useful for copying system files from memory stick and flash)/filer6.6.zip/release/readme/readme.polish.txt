﻿PSP Filer wersja 6.6

/* Please donate (only U.S. $10), if you feel Filer useful.
Paypal & credit card will be accepted. */
http://www.geocities.jp/mediumgauge/

<OSTRZEŻENIE!>
Używasz na WŁASNĄ ODPOWIEDZIALNOŚĆ!!!

<DISCLAIMER>
Program ten może spowodować poważne uszkodzenie twojej konsoli PSP, albo z powodu Twojego braku wiedzy, albo z powodu błędów w programie.
Autor programu nie ponosi w żaden sposób odpowiedzialności za zniszczenia, które program może spowodować.
Jeśli zbrickujesz swoje PSP będzie to tylko i wyłącznie Twoja wina.
(wszelkie błędy proszę zgłaszać na adres mediumgauge@yahoo.co.jp, możliwe, że zostaną poprawione w następnych wersjach)

- program używa czcionki "shinonome font"
- do wyświetlania obrazów PNG, użyto biblioteki libpng1.2.8 + zlib
- do wyświetlania obrazów JPEG, użyto biblioteki jpeg-6b

<kalwiszologia w programie>
select:pokaż pomoc
 O: zmiana języka (japoński, angielski, hiszpański, portugalski, niemiecki, rosyjski, Włoski, polski, francuski, serbski, węgierski, bułgarski, grecki)
 kwadrat: zapisuje ustawienia

start:
 zmienia aktualne urządzenie (MS0 > UMD > flash0 > flash1 > RAMDISK)

krzyżak w górę i w dół:
 ruchy kursorem

analog w górę i w dół:
 szybkie ruchy kursorem

krzyżak w lewo + O:
 powrót do wyższego folderu

krzyżak w lewo + start:
 ustawia folder jako startowy (pojawi się po ponownym włączeniu Filera)

krzyżak w prawo:
 zaznacza/odznacza wszystkie pliki w aktualnym folderze

analog w lewo:
 wyświetlanie krószych nazyw plików

analog w prawo:
 wyświetlanie dłuższych nazyw plików

kwadrat:
 zaznacza aktualny plik

O:
 zwija/rozwija aktualny folder
 wyświetla obraz .jpg / .jpeg / .bmp / .png
 odtwarza dźwięk .wav / .mp3.
 pokazuje zawartość innych plików

trójkąt: menu programu
   O: tuner i metronom
   kwadrat: podgląd pamięci
    można podejrzeć główną pamięć, VRAM, i scratch pad.
    uwaga: ta funkcja wymaga baterii, ponieważ cały czas odczytuje pamięć
     nie pozostawiaj PSP z włączonym podglądem pamięci
   trójkąt: włącza/wyłącza tło (jeśli jest ustawione)
   R: zgrywanie zawartości dysku UMD na kartę pamięci
    dyski UMD są zgrywane do folderu ms0:/iso/.
    jeśli folder /iso/ nie istnieje, to zostanie automatycznie utworzony.
    jeśli na karcie zabraknie miejsca, wystarczy zmienić kartę, a zgrywanie będzie kontynuowane
    po zakończeniu, należy umieścić wszystkie podzielone pliki (z nazwami *.1, *.2, ...itd) w jednym folderze na PC, kliknąć "cat.bat" który został utworzony razem z ostatnią częścią, pliki zostaną scalone w jedno iso.
   L: operacje na pamięci flash
    przy pomocy Filer'a można wykonać kopię flash0/flash1 na karcie pamięci.
    dodatkowo w HACKER MODE (TRYB HAKERA), Filer może przywracać kopie flash0/flash1 z obrazu na karcie pamięci.
    Można korzystać z tej opcji, aby przywrócić oryginalny flash0/flash1.
    po zakończeniu przywracania, mogą pojawić się problemy z Filerem, należy wyjść z programu i uruchomić konsolę ponownie.
   krzyżak w górę: połączenie USB
    w tej wersji, po rozłączeniu, Filer nie może prawidłowo odczytać zmienionych plików, dlatego, należy wyjąć i włożyć ponownie kartę pamięci, gdy program o to zapyta.
   krzyżak w prawo: zmiana ustawienia kolorów
    Można zmienić kolory programu, aby zapamiętać ustawienia należy wcisnąć O.
   krzyżak w lewo: zmiana kolejności ikon w XMB
    Opcja pozwala zmienić kolejność ikonek w XMB. Wciśnij O aby złapać ikonę, następnie zmień jej położenie wciskając góra/dół. Wciśnij START aby zapisać.

X: operacje na pliku
   O: kopiuj/przenieś pliki
     na zaznaczonym pliku: kopiuj/przenieś wszystkie zaznaczone pliki.
     na niezaznaczonym pliku: kopiuj/przenieś ten plik.
     na folderze: kopiuj/przenieś wszystkie pliki i podfoldery w tym folderze.
     uwaga.1: kiedy przenosisz pliki, w rzeczywistości są one 'kopiowane i kasowane' dlatego operacji nie można wykonać, jeśli jest za mało miejsca na aktualnym urządzeniu.
     uwaga.2: nie możesz modyfikować flash0/flash1 dopóki nie włączysz TRYBU HAKERA.
   kwadrat: usuwa pliki
     na zaznaczonym pliku: usuwa wszystkie zaznaczone pliki.
     na niezaznaczonym pliku: usuwa ten plik.
     na folderze: usuwa wszystkie pliki i podfoldery w tym folderze.
   R: zmienia nazwę aktualnego pliku lub folderu.
   L: tworzy nowy folder
   góra: pokaż / edytuj informacje
    w katalogu głównym MS / flash0 / flash1:
     pokazuje informacje o urządzeniu i sprawdza strukturę klastrów.
     wciśnij O aby zobaczyć szczegółowe informacje.
    w katalogu głównym dysku UMD:
     pokazuje rozmiar ISO.
    w katalogu głównym RAMDISKu:
     pokazuje ilość pamięci zajętej przez pliki znajdujące się w RAMDISKu.
    na pliku lub folderze:
     pokaż i edytuj atrybuty i datę pliku lub folderu.
     w TRYBIE HAKERA możesz edytować pliki w flash0/flash1.
     na pliku:
       wciskając O, zostanie obliczona suma MD5 pliku.

R: sortuje pliki w aktualnym folderze. (sortowanie nie zostanie zachowane)
  możliwe opcje:
    wg nazwy (N) > wg rozszerzenia (E) > wg rozmiaru (S) > wg daty (D) >
    wg rozmiaru malejąco (s) > wg daty malejąco (d) > nie posortowane

L: przełączanie między wyświetlaniem rozmiaru plików: Bajty, KiloBajty i MegaBajty

krzyżak w lewo + R:
  włącza/wyłącza TRYB HAKERA.
  OSTRZEŻENIE: w TRYBIE HACKERA możesz uszkodzić swoje PSP (NIE UŻYWAJ, JEŚLI NIE MASZ POJĘCIA CO NAPRAWDĘ ROBISZ).

<klawiszologia w przeglądarce tekstu>
krzyżak w górę i w dół: ruchy kursorem.
analog w górę i w dół: szybsze ruchy kursorem.
krzyżak w lewo i w prawo: przewijanie w lewo i prawo (w trybie FLAT).
analog w lewo i w prawo: szybkie przewijanie w lewo i w prawo (w trybie FLAT).
LR: (L) ładuje poprzednią stronę, (R)ładuje następną.
trójkąt: zmiana tabulacji 4/8 (w trybie BEND tekst jest ładowany ponownie).
kwadrat: edytor hex.
O: przełącza między trybem FLAT i BEND (zawijanie wierszy).
 tryb FLAT : można przewijać tekst w prawo i w lewo.
 tryb BEND : tekst jest zawijany, aby w całości zmieścić się na ekranie.
 przełączając się między trybami tekst jest ładowany ponownie.
start: zmiana kodowania znaków
select: pomoc
X: powrót do Filer'a.

<klawiszologia w przeglądarce obrazków>
analog: przewijanie.
O: dopasowanie rozmiaru do wielkości ekranu.
kwadrat: przełączenie na edytor hex.
start + trójkąt: zapisuje aktualny obraz jako tło.
start + O: zmiana jasności obrazka.
X: powrót do menu głównego Filer'a.
R*: zmniejsza przybliżenie.
L*: zwiększa przybliżenie.
krzyżak w prawo*: przełącza na kolejny obrazek (w aktualnym folderze).
krzyżak w lewo*: przełącza na poprzedni obrazek (w aktualnym folderze).
krzyżak w górę i w dół*: obraca obrazek.
* = tym przyciskom można przypisać inne funkcje.

<edytor hex (edytor heksadecymalny / edytor binarny>
krzyżak w górę i w dół: ruchy kursorem.
analog w górę i w dół: szybsze ruchy kursorem.
krzyżak w lewo i w prawo: ruchy kursorem (tylko w plikach edytowalnych).
LR: (L) ładuje poprzednią stronę, (R)ładuje następną.
trójkąt: zmiana sposób wyświetlania: bajt/word/longword.
kwadrat: przełącza między przeglądarkami hex/tekst lub hex/grafika.
O: zwiększa wartość o +1 (tylko w plikach edytowalnych).
start: zapis (tylko, jeśli plik został zmieniony).
select: pomoc
X: powrót do Filer'a.

uwaga: nie można edytować następujących plików
- których rozmiar jest większy niż dostępna pamięć (około 22 MB)
- plików w archiwach (.zip, .rar, .iso, .cso)
- plików w flash0/flash1, dopóki nie uruchomimy TRYBU HAKERA

<operacje na plikach>
Większość operacji jest wykonywana poprzez RAMDISK.
PSP ma 24 MB pamięci dla użytkownika,z czego możemy użyć około 20 MB. Dlatego nie można kopiować/wklejać zbyt dużych plików do RAMDISKu.
Nie zostawiaj tam zbyt wiele plików, ponieważ jest on używamy jako katalog tymczasowy.

<porady na temat tła>
- jeśli wrzucisz do katalogu Filler'a plik wallpaper.bmp / wallpaper.jpg / wallpaper.png, (tylko bmp,jpg i png) Filer wykryje ten plik przy następnym starcie i ustawi go jako tło.
- w przeglądarce plików, wciśnięcie start + trójkąt spowoduje zapisanie obrazka jako "wallpaper.bmp" i ustawienie go jako tła.

<podziękowania>
Dla djroman za przetłumaczenie na język hiszpański.
Dla Me'Katis za przetłumaczenie na język portugalski.
Dla Experiment1106 za przetłumaczenie na język niemiecki.
Dla ikari_kun za przetłumaczenie na język rosyjski.
Dla cj92 za przetłumaczenie na język włoski.
Dla soulburn za przetłumaczenie na język polski.
Dla Mizou93 za przetłumaczenie na język francuski.
Dla FillerUE za przetłumaczenie na język serbski.
Dla eM82 za przetłumaczenie na język węgierski.
Dla SaCReD VoIcE za przetłumaczenie na język bułgarski.
Dla michael saant  za przetłumaczenie na język grecki.
Dla RaiderX za wykonanie ikony.
Dla clint, evilseph, moca, tuw i fergie za pomoc w debuggowaniu.
Dla Daniel za poprawienie języka angielskiego.
