PSP Filer version 6.6

/* Please donate (only U.S. $10), if you feel Filer useful.
Paypal & credit card will be accepted. */
http://www.geocities.jp/mediumgauge/

<ATTENTION!>
Use it at your OWN RISK!!!.

<DISCLAIMER>
This software may cause severe damage to your PSP by your lack of knowledge or by bugs Filer may have.
The creator of psp filer cannot be held responsible for any damage you may cause.
If you brick your psp its no ones fault but your own.
(report bugs to mediumgauge@yahoo.co.jp, and it may be fixed in future version)

- this software uses "shinonome font".
- to view PNG picture, libpng1.2.8 + zlib is used.
- to view JPEG picture, jpeg-6b library is used.

<Filer controls/how to>
select:show help
 circle: change language (Japanese, English, Spanish, Portguese, German, Russian, Italy, Polish, French, Seriban, Hungarian, Bulgarian, Greek, Swedish)
 square: save settings

start:
 move to next device. (MS0 > UMD > flash0 > flash1 > RAMDISK)

digital up & down:
 move cursor

analog up & down:
 move cursor (fast)

digital left + circle:
 move to parent folder.

digital left + start:
 save this folder to default. (shows this folder at startup)

digital left + triangle:
 move to default folder.

digital right:
 mark/unmark all of current folder's files.

analog left:
 draw file name shorter.

analog right:
 draw file name longer.

square:
 mark current file.

circle:
 collapse/extend on folder.
 view picture on .jpg / .jpeg / .bmp / .png.
 playback on .wav / .mp3.
 show file on others.

triangle: application menu
   circle: instrument tuner & metronome
   square: memory viewer
    you can see main memory, VRAM, and scratch pad.
    note: this feature needs battery because it reads memory on every frame.
     do not leave PSP showing memory viewer.
   triangle: toggle showing wallpaper (if using wallpaper)
   R: UMD device ripping
    Filer rips a UMD image into ms0:/iso/ folder.
    if /iso/ directory does not exist, it is created.
    if MS Duo is full, change MS Duo, and Filer will continue ripping.
    and after all is done, collect all divided files (named *.1, *.2, ...etc) to one folder in PC, use "cat.bat" which is created in the last part folder, then you will get a complete ISO file.
   L: maintenance flash memory
    Filer backups flash0/flash1 image to the MS Duo.
    and, when in HACKER MODE, Filer can restore flash0/flash1 image from MS Duo.
    You may use this feature to recover flash0/flash1 images.
    after restoring is done, flash images do not respond correctly files (because of bug in the psp), I recommend to quitting Filer and booting again.
   up: connect USB
    in this version, after disconnecting, Filer cannot read chaged files by PC correctly, so, please re-insert MS Duo as Filer prompts.
   right: change color setting
    you can change color setting and you can then save by pushing circle.
   left: re-order XMB icons
    you can re-order XMB icons. Press circle and hold one icon, and move it to any place by pushing up & down. save them by pushing start.
   down: modify CPU speed
    you can change CPU speed.
   start: toggle enable/disable analog pad

cross: file operation
   circle: copy/move files
     on marked file: copy/move all marked files.
     on unmarked file: copy/move this file.
     on folder: copy/move all files & subfolders in this folder.
     note.1: when you move files, it only does 'copy & delete' therefore the operation cannot be done if there is not enough space on current device.
     note.2: you cannot modify flash0/flash1 unless you activate HACKER MODE.
   square: remove files
     on marked file: remove all of the marked files.
     on unmarked file: remove this file.
     on folder: remove all the files & subfolders in this folder.
   R: rename filerename current file / folder.
   L: create a new folder
   up: show / edit info
    on root directory of MS / flash0 / flash1:
     shows device info and check cluster structure.
     press circle to show detailed info.
    on root directory of UMD:
     shows phygical size & described size in ISO.
    on root directory of RAMDISK:
     shows memory usage occupied by RAMDISK files.
    on file or folder:
     shows file/folder info and edit attributes & timestamps.
     when in HACKER MODE you may even edit flash0/flash1's files.
    on file:
     pushing circle, MD5 of the file will be calculated.
   right: send current file via ADHOC wifi.
    (works on Kernel3)
   left: receive a file into current folder via ADHOC wifi.
    (works on Kernel3)
   down: activate audio player

R: sort files on current folder. (the sorted file order will not be saved)
  order changes following:
    by name(N) > by ext(E) > by size(S) > by date(D) >
    by smaller size(s) > by older date(d) > not sorted

L: toggle file size mode:
  changes draw mode: drawn by bytes, Kbytes, Mbytes,
    by bytes (with directory), Kbytes (w/d) and Mbytes (w/d)

digital left + R:
  toggle HACKER MODE.
  WARNING: use HACKER MODE at your OWN RISK(DO NOT USE IF YOU ARE A NOOB).

<text viewer controls/how to>
up & down: moves the cursor.
analog up & down: moves the cursor (faster).
analog left & right: fast scroll left & right (works in FLAT mode).
LR: (L) loads the previous page (R) loads the next page.
triangle: change tab stop 4/8 (text is reloaded when in BEND mode).
square: moves to binary editor.
circle: toggle FLAT mode / BEND mode.
 FLAT mode : you can scroll left & right to read text.
 BEND mode : all text is rearanged to fit the screen size.
 text is reloaded when switching between BEND mode & FLAT mode.
right: line editor.
   note: edited files will be forced to be shift-jis encoding when it is saved. And, non-shift-jis file and binary file may not be edited & saved correctly.
start: change encoding
select: show help
cross: return to Filer.

<picture viewer controls/how to>
analog: scroll picture.
circle: changes the picture size to fit the screen.
square: changes to the binary editor.
start & triangle: save current picture as a wallpaper.
start & circle: make picture darker.
circle & square: mark/unmark current picture.
start & digital left, right, up and down: move to the edge of the picture.
cross: returns you to Filer (main menu).
R*: shrinks the picture (zoom out).
L*: enlarges the picture (zoom in).
digital right*: moves to the next picture (in current folder).
digital left*: moves to the previous picture (in current folder).
digital up & down*: rotates the picture.
* = user can customize those key assign.

<binary editor controls/how to>
up & down: moves the cursor.
analog up & down: moves the cursor (faster).
left & right: moves the cursor (editable file only).
LR: (L) loads the previous page (R) loads the next page.
triangle: change byte/word/longword mode.
square: moves to text/picture viewer.
circle: modify value +1 (editable file only).
start: save (only when changed).
select: show help
cross: return to Filer.

note:Following files could not be edited.
- the file size is larger than memory (about 22MB).
- bound in archive (.zip, .rar, .iso, .cso) file.
- placed in flash0/flash1 unless activating HACKER MODE.

<filer operation tips>
most of operation is done via RAMDISK.
PSP has 24MB memory for user, and we can use about 20MB for RAMDISK.
That's why we cannot copy/paste files that are to large , and when large files have been copied/pasted in the RAMDISK, Filer cannot do its operations properly because of a shortage of memory.
remember not to leave to many files on the RAMDISK - it is only used as a temporary storage area and you better remove the files soon after doing the intended operation.

<wallpaper tips>
- if you put either  wallpaper.bmp / wallpaper.jpg / wallpaper.png,(only use bmp,jpg & png) Filer detects the picture when it next starts up, and uses the picture as the wallpaper.
- since version 5.3, you can put filer / text / binary [.bmp/.jpg/.png] and Filer changes background as mode changes.
- in picture viewer, push start & triangle, on the picture of your choice and it will be saved as "wallpaper.bmp" and registered as a wallpaper.

<UMD ripping tips>
Though the reason is not clear now, the last 1-3 record of UMD cannot be read from filesystem. So, doing ripping operation, the iso file is 2k-6k (1record = 2kbytes) smaller than it should be. Since version 3.9, Filer try to fill those "lost tail records" by following sequence:

1. Filer rips as large as possible.
2. Filer checks expected size by peeking ISO file, and if it is larger than ripped size, create a differential size data which is filled with 0.
3. Filer searches ISO file structure, and if there are files which uses "lost tail records", copy those data into right place of the differential data.
4. Filer appends the differential data to the ripped ISO file.

It seems to work fine now. Give me reports if the feature does not work well - to fix it.

<thanks>
Thanks djroman to translate into Spanish.
Thanks Me'Katis to translate into Portguese.
Thanks Experiment1106 to translate into German.
Thanks ikari_kun to translate into Russian.
Thanks cj92 to translate into Italian.
Thanks soulburn to translate into Polish.
Thanks Mizou93, a member of www.psp-ground.net, to translate into French.
Thanks FillerUE to translate into Serbian.
Thanks eM82 to translate into Hungarian.
Thanks SaCReD VoIcE to translate into Bulgarian.
Thanks michael saant to translate into Greek.
Thanks P_cool, the one of the owners of www.swepsp.se.nu, to translate into Swedish.
Thanks RaiderX to make icon.
Thanks clint, evilseph, moca, tuw and fergie to help debugging.
Thanks Daniel to correct English.
