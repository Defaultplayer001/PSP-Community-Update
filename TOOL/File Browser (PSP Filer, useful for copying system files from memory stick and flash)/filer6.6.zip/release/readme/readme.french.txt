PSP Filer version 6.6

/* Please donate (only U.S. $10), if you feel Filer useful.
Paypal & credit card will be accepted. */
http://www.geocities.jp/mediumgauge/

<ATTENTION!>
Utilisez ce logiciel � vos propres risques !!!.

<DISCLAIMER>
Ce logiciel pourrait endomager gravement votre PSP par votre manque de connaissance ou par un bug que Filer pourrait avoir.
Le cr�ateur de PSPFiler ne pourrait �tre tenu pour r�sponsable des dommages que vous pouvez causer.
Si vous bricker votre PSP, �a ne sera la faute de personne. Ce sera seulement votre faute.
(reporter les bugs � mediumgauge@yahoo.co.jp, et ils pourront �tre corriger dans les prochaines versions)

- ce logiciel utilise "shinonome font".
- pour voir les images PNG, libpng1.2.8 + zlib sont utilis�s.
- pour voir les images JPEG, jpeg-6b library sont utilis�s.

<Contr�les du Filer/Comment faire>
select:afficher l'aide
 Rond: changer la langue (Japonnais, Anglais, Espagnol, Portguais, Allemand, Russe, Italien, Polonais, Fran�ais, Serbe, Hongrois)
 Carr�: enregistrer les pr�f�rences

Start:
 Passer au p�riph�rique suivant. (MS0 > UMD > flash0 > flash1 > RAMDISK)

Fl�ches directionnelles bas et haut:
 D�placer le curseur

Analogue haut et bas:
 D�placer le curseur (rapidement)

Fl�che directionnelle gauche + rond:
 Aller au dossier parent.

Fl�che directionnelle gauche + Start:
 Utiliser le dossier courant comme dossier par d�faut. (Afficher ce dossier au d�marrage de PSPFiler)

Fl�che directionnelle droite:
 Marquer/d�marquer tous les fichiers du dossier courant.

Analogue gauche:
 Affiche un nom de fichier plus court.

Analogue droit:
 Affiche le nom de fichier entier.

Carr�:
 Marquer le fichier courant.

rond:
 ouvrir/r�duire un dossier.
 afficher les images .jpg / .jpeg / .bmp / .png.
 lire les morceaux .wav / .mp3.
 ouvrir les autres types de fichiers.

triangle: menu de l'application
   rond: Tuner et m�tronome pour instrument
   carr�: visualisateur de la m�moire
    vous pouvez voir la m�moire principale, VRAM, et le scratch pad .
    note: cette option n�c�ssite que la psp soit sur batterie car elle lit la m�moire.
     Ne laissez pas la psp sur visualisateur de m�moire.
   triangle: activation de l'affichage du fond d'�cran (si vous utilisez un fond)
   R: Rippage d'un UMD
    Filer rip les UMD dans le dossier ms0:/iso/ .
    Si le dossier /iso/ n'existe pas, il sera cr��.
    Si la MS Duo est pleine, changer la MS Duo, et Filer continuera le rip.
    et apr�s que tout soit finit, r�cup�rez toutes les parties du fichier (nomm�es *.1, *.2, ...etc) dans un dossier sur le PC, et utilisez "cat.bat" 
	qui est cr�� � la fin du rip dans le dossier o� sont enregistr�s les parties du fichier, apr�s �a vous aurez un fichier ISO complet.
   L: maintenance du flash
    Filer enregistre les sauvegardes du flash0/flash1 dans la MS Duo.
    et, dans le MODE HACKER, Filer peut restaurer des sauvegardes du Flash0/Flash1 depuis la MS Duo.
    Vous pourrez utiliser cette option pour restaurer une copie du Flash0/Flash1.
    � la fin de la restauration, les fichiers de l'image du flash ne r�pondent pas correctement (� cause d'un bug dans la psp), 
	je recommande de red�marrer Filer.
   fl�che directionnelle haut: connecter la PSP par USB
    dans cette version, apr�s la d�connection, Filer ne peut lire correctement les fichiers qui ont �t� transf�r�, donc il faudra r�inserer la MS Duo.
   fl�che directionnelle droite: changer les param�tres de couleur
    vous pouvez changer les param�tres de couleur puis enregistrer les modifications en appuyant sur rond.
   fl�che directionnelle gauche: r�organiser les ic�nes du XMB
    vous pouvez r�organiser les ic�nes du XMB. Appuyez sur rond et maintenez sur une ic�ne, et d�placez la n'importe o� avec les fl�ches heut et bas. 
		sauvegardez les changements en appuyant sur start.

croix (X): op�rations sur fichier
   rond: copier/d�placer des fichiers
     quand des fichiers sont s�l�ctionn�s: copier/d�placer tous les fichier marqu�s.
     quand aucun fichier s�l�ctionn�: copier/d�placer le fichier actuel.
     quand le curseur est sur un dossier: copier/d�placer tous les fichiers et sous-dossiers de ce dossier.
     note.1: quand vous d�placez des fichiers, Filer ne fait que 'copier & supprimer ' c'est pourquoi l'op�ration ne peut �tre r�aliser si il n'y a pas assez d'espace sur le p�riph�rique.
     note.2: vous ne pouvez �diter/d�placer des fichiers du Flash0/Flash1 sans �tre dans le MODE HACKER.
   carr�: supprimer des fichier
     quand des fichiers sont s�l�ctionn�s: supprimer tous les fichiers marqu�s.
     quand aucun fichier n'est s�l�ctionn�: supprimer le fichier actuel.
     quand le curseur est sur un dossier: supprimer tous les fichiers & sou-dossiers dans ce dossier.
   R: renommer le fichier/dossier actuel.
   L: cr�er un nouveau dossier
   Fl�che Directionnelle Haut: Afficher / Editer les infos
    A la racine de la MS / du flash0 / du flash1:
     Affiche les d�tails du p�riph�rique et la structure de ses clusters.
     Appuyez sur Rond pour afficher les d�tails avanc�s.
    A la racine d'un UMD:
     Affiche la taille physique et la taille qu'occupe l'ISO.
    A la racine de la m�moire RAM:
     Affiche la taille de la m�moire occup�e.
    Sur un fichier ou un dossier:
     Affiche les infos du fichier/dossieret �dite les attributs ainsi que les dates de modification.
     En mode HACKER vous pourrez m�me �diter les fichiers du flash0/flash1.
    Sur un fichier:
     Appuyez sur Rond pour calculer le MD5 d'un fichier.

R: classer les fichiers du dossier courant. (l'odre des fichiers ne sera pas sauvegard�)
  order changes following:
    par nom(N) > par extension(E) > par taille(T) > par date(D) >
    par la plus petite taille(t) > par la date la plus ancienne(d) > non class�

L: activer le mode affichage des tailles des fichiers: class� par octets, Koctets et Moctets.

fl�che directionnelle gauche + R:
  activation du MODE HACKER.
  AVERTISSEMENT: Utilisez le MODE HACKER � vos propres risques (NE L'UTILISEZ PAS SI VOUS ETES UN DEBUTANT).

<Commandes du mode visualisation de texte/Comment faire>
Fl�ches directionnelles haut et bas: d�placer le curseur.
Analogue haut et bas: d�placer le curseur (rapidement).
Fl�ches directionnelles gauche et droite: d�filement gauche droit (marche en mode FLAT).
Analogue gauche et droit: d�filement rapide gauche droit (marche en mode FLAT).
LR: (L) aller � la page pr�c�dente (R) aller � la page suivante.
Triangle: changer l'arr�t de la tabulation 4/8 (le texte est recharger quand Filer est en mode bend).
Carr�: passe en �diteur binaire.
Rond: activer le mode FLAT/BEND.
Mode FLAT : vous pouvez faire d�filer la page horizontalement pour lire le texte.
Mode BEND : tout le texte est r�organiser pour ne pas tenir sur l'�cran horizontalement.
 Le texte est recharg� quand vous passez du mode BEND au mode FLAT et inversement.
START: changer l'encodage
Select: afficher l'aide
Croix (X): retour au Filer.

<Commandes du mode visualisation d'images/Comment faire>
Analogue: d�filement de l'image.
Rond: changer la taille des images pour tenir sur l'�cran.
Carr�: passer en �diteur binaire.
START & triangle: enregistrer l'image en tant que fond d'�cran.
START & rond: assombrir l'image.
Croix (X): retour au Filer (menu principal).
R*: r�duit la taille de l'image (zoom arri�re).
L*: agrandit l'image (zoom avant).
Fl�che directionnelle droite*: passer � l'image suivant (dans le dossier actuel).
Fl�che directionnelle gauche*: passer � l'image pr�c�dente (dans le dossier actuel).
Fl�ches directionnelles haut et bas*: pivoter l'image.
* = l'utilisateur peut changer les touches.

<Commandes de l'�diteur binaire/Comment faire>
Fk�ches directionnelles Haut et Bas: D�placer le curseur.
Analogue haut et bas: D�place le curseur (Rapidement).
Fl�ches directionnelles Gauche et Droite: D�place le curseur (fichiers �ditables seulement).
G�chettes L et R: (L) Charger la page pr�c�dente (R) Afficher la page suivante.
Triangle: Change le mode byte/mot/longs mots.
Carr�: Charger le visualisateur d'images/textes.
Rond: Changer la valeur (+1) (fichiers �ditables seulement).
Start: Enregistrer (Seulement apr�s changement).
Select: Afficher l'aide.
Croix: Retourner au gestionnaire de fichiers.

Note: Les fichiers suivant ne peuvent �tre modifi�s
- La taille du fichier est sup�rieur � la taille de la m�moire (environ 22 Mo).
- Fichier inclus dans une archive (.zip, .rar, .iso, .cso).
- Fichier se trouvant dans le Flash1/Flash0 � part en activant le HAcKER Mode.

<Astuces pour le menu d'op�rations sur fichier>
La plupart des op�rations sont r�alis�s via la RAMDISK.
La PSP a 24MO de m�moire d�di�e � l'utilisateur, et nous pouvons en utiliser 20 Mo environ pour la RAMDISK.
C'est pour cela que nous ne pouvons pas copier des fichiers de trop grande taille , et quand des trop gros fichiers sont sauvegard� dans la RAMDISK, 
Filer ne peut r�aliser ses op�rations correctement � cause d'un manque de m�moire.
Rappelez-vous de ne pas laisser de trop gros fichiers dans la RAMDISK - c'est seulement utilis� comme une zone de stockage temporaire 
et vous feriez mieux de supprimer les fichiers dans la RAMDISK apr�s les op�rations soient termin�es.

<Astuces pour le fond d'�cran>
- Placez un fichier  wallpaper.bmp / wallpaper.jpg / wallpaper.png,(utilisez seulement des fichiers bmp,jpg & png) dans votre MS Duo et Filer d�tectera 
	l'image au d�marrage et l'utilisera comme fond d'�cran.
- Dans la visualisation d'images, appuyez sur START et TRIANGLE, dans l'image de votre choix et elle sera sauvegard�e en tant que "wallpaper.bmp" 
		et utilis�e comme fond d'�cran.

<Astuces pour le Rippind d'UMD>
J'ai pens� que la raison n'�tait pas claire en ce moment, le dernier tiers de la sauvegarde d'un UMD ne peut �tre lu par les fichiers syst�mes. Donc apr�s une op�ration de Rip la taille de l'ISO est environ de 2k-6k (1 enregistrement = 2kbytes) plus petit que la normale. Depuis la verion 3.9, Filer tente de remplir ces "fins d'enregistrements" non r�cup�r�s par le proc�d� suivant:

1. Filer rip les fichiers ISO aussi grand que possible.
2. Filer compare la taille de l'ISO et la taille attendue, en cas de diff�rence il comble le fichier ISO avec des 0 suppl�mentaires afin d'atteindre la taille attendue.
3. Filer v�rifie la structure de l'ISO, et si il y a des fichiers pr�sentant une "fin d'enregistrement perdue", il copie ces fichiers dans le bon emplacement.
4. Apr�s reconstitution des fins d'enregistrement perdues, Filer copie le tout dans l'ISO ripp�.

Ca semble fonctionner � pr�sent. Avertissez-moi si la fonction ne fonctionne pas bien - pour la r�parer.

<Remerciements>
Merci � djroman pour avoir traduit Filer en Espagnol.
Merci � Me'Katis pour avoir traduit Filer en Portuguais.
Merci � Experiment1106 pour avoir traduit Filer en Allemang.
Merci � ikari_kun pour avoir traduit Filer en Russe.
Merci � cj92 pour avoir traduit Filer en Italien.
Merci � soulburn pour avoir traduit Filer en Polonnais.
Merci � Mizou93, un membre de www.psp-ground.net, pour avoir traduit Filer en French.
Merci � FillerUE pour avoir traduit Filer en Serbe.
Merci � eM82 pour avoir traduit Filer en Hongroi.
Merci � SaCReD VoIcE pour avoir traduit Filer en Bulgare.
Merci � michael saant pour avoir traduit Filer en Grecque.
Merci � RaiderX pour avoir r�alis� les ic�nes.
Merci � clint, evilseph, moca, tuw et fergie pour avoir aid� � corriger les bugs.
Merci � Daniel pour la correction de l'Anglais.
