﻿PSP Filer 6.6-es változat
-------------------------
/* Please donate (only U.S. $10), if you feel Filer useful.
Paypal & credit card will be accepted. */
http://www.geocities.jp/mediumgauge/

<FIGYELEM!>
Csak saját felelősségre használd !!!

<NYILATKOZAT>
Ez a szoftver súlyos károkat okozhat a PSP-dnek hiányos tudásod vagy a Filer esetleges bugjai (hibái) révén.
A PSP Filer alkotója nem tehető felelőssé semmilyen kárért/hibáért, amit te (esetleg) okozol.
Ha brick-eled ("tetszhalott" állapotba kerülne. Se kép, se hang, csak a LED) a PSP-d, az csakis a Te hibád. Despertar del Cementerio v4-el tudod visszahozni működőképes állapotba.
(A Filer esetleges bugjait/hibáit (tkpn. a hibajelentéseket) erre az e-mail címre tudod elküldeni: mediumgauge@yahoo.co.jp, és lehetséges, hogy javítva lesz egy következő változatban. /Lehetőség szerint angolul írd./)

- ez a szoftver a következő betűtípust használja: "shinonome".
- a PNG képek megjelenítéséhez libpng1.2.8 + zlib van használva.
- a JPEG képek megjelenítéséhez jpeg-6b könyvtár van használva.
-------------------------
*******************************************************************
<Filer irányítás/Billentyűfunkciók>

select: Súgó megjelenítése
KÖR: 	nyelvváltoztatás (Japán, Angol, Spanyol, Portugál, Német, Orosz, Olasz, Lengyel, Francia, Szerb, Magyar)
4SZÖG: 	beállítások mentése
start: 	váltás a következő eszközre (MS0 > UMD > flash0 > flash1 > RAMDISK)
Fel & Le (nyilak): 	kurzor mozgatása
Fel & Le (Analóg-kar): 	kurzor mozgatása (gyors)
Balra (nyíl):		aktuális mappában összes fájl kijelölésének visszavonása.
Jobbra (nyíl):		aktuális mappában összes fájl kijelölése.
Balra (Analóg-kar):	fájlnév részleteinek rejtése
Jobbra (Analóg-kar):	fájlnév részleteinek bővebb mutatása
4SZÖG:			aktuális fájl kijelölése.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
KÖR:
- mappa részleteinek listázása/bezárása
- .jpg / .jpeg / .bmp / .png kiterjesztésű képek lejátszása.
- .wav / .mp3 fájlok lejátszása.
- File tartalmának megjelenítése.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
3SZÖG: alkalmazás menü
----------------------------------
=KÖR: zenei eszközhangoló & metronóm
=4SZÖG: memória ellenőrző
----Láthatod a fő-memóriát, a VRAM-ot,ill. a "scratch pad" (ideiglenesen létrehozott) részt is.
------megjegyzés: ez a funkció igénybe veszi az akkut, mivel lépésenként olvassa ki a memóriát.
------Ne hagyd a PSP-t a memória ellenőrző módban.
=3SZÖG: háttérkép mutatása/elrejtése (háttérkép használata esetén)
=JOBB-KAR: UMD rippelése/másolása
----A Filer a MemStick "ISO" mappájába rippeli az UMD tartalmát.
----Ha az ISO mappa nem létezik, létrehozza.
----Ha a MemStick betelik, cseréld ki egy másikra és a Filer folytatni fogja a rippelést.
----S végül ha minden elkészült, másold az összes széttagolt fájlt (*.1, *.2, ...stb.) a PC-den egy üres mappába, majd futtasd le a "cat.bat"-ot (amely az utolsó darabolt fájl mappájában található) s így kapsz egy kész ISO-fájlt.
=BAL-kAR: Flash-memória karbantartása
----A Filer a flash0/flash1-ről a MemStick-re készíti el a biztonsági kép(/image)-fájlokat.    
----És ha HACKER MÓD-ban vagy, akkor a Filer képes visszaállítani a flash0/flash1-et a MemStick-en lévő képfájlból. 
----Ha a visszaállítás befejeződött, a flash képek nem jelzik helyesen a fájlokat (a psp-ben lévő bug/hiba miatt), ezért ajánlom, hogy lépj ki a Filer-ből és indítsd újra a PSP-d.
=Fel (nyíl): USB-csatlakozás
----Ebben a verzióban, a csatlakozás bontása után, a Filer nem tudja a PC által módosított fájlokat helyesen olvasni, ezért kérlek vedd ki, majd tedd be ismét a MemStick-et amikor a Filer erre kér.
=Jobb (nyíl): Színbeállítás változtatása
----Megváltoztathatod a színbeállításokat, majd utána KÖR lenyomásával el is mentheted.
=Bal (nyíl): ISO/Homebrew ikonok sorrendjét lehet itt beállítani
----Átrendezheted az XMB ikonok sorrendjét. Menj rá az egyik ikonra, és nyomd meg a KÖR-t, a Fel/Le nyilakkal tudod a sorrendjét megváltoztatni. Ha kész, akkor a start gombot kell megnyomni a mentéshez.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
X: fájl műveletek
----------------------------------
=KÖR: fájl másolása/áthelyezése
----kijelölt fájlnál: összes kijelölt fájl másolása/áthelyezése
----nem kijelölt fájlnál: csak a kijelölt fájl másolása/áthelyezése
----mappán állva: összes fájl és almappa bemásolása/áthelyezése ebbe a kijelölt mappába
------megjegyzés1: amikor fájlokat mozgatsz, csak "másol és töröl" ezért ez a művelet nem végrehajtható, ha nincs elég szabad hely az adott eszközön.
------megjegyzés: a Flash0/Flash1-et csak HACKER-módban tudod módosítani !
=4SZÖG: fájl eltávolítása
----kijelölt fájlnál: összes kijelölt fájl törlése
----nem kijelölt fájlnál: csak a kijelölt fájl törlése
----mappán állva: összes fájl és almappa törlése az adott mappában
=JOBB-kAR: aktuális fájl/mappa átnevezése
=BAL-KAR: új mappa létrehozása
=Fel (nyíl): infó mutatása/szerkesztése
----Memory Stick/Flash0/Flash1 főkönyvtárában (gyökérkönyvtárában) állva: Eszközinformáció megjelenítése ill. cluster-struktúra ellenőrzése. Nyomd meg a KÖR-t a részletesebb információ végett.
----UMD-lemez főkönyvtárában állva: fizikai méret mutatása és az iso becsült méretét.
----RAMDISK főkönyvtárában állva: (RAMDISK fájljai által lefoglalt) memóriahasználat megjelenítése.
----Fájlon/Mappán állva: fájl/mappa információ mutatása (attribútumok, módosítás, létrehozás időpontja)
-------HACKER MÓD-ban még a flash0/flash1 fájljait is szerkesztheted.
----Fájlon állva: KÖR lenyomására az MD5 ellenőrző szám kalkulálása.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
JOBB-KAR: aktuális mappában lévő fájlokat sorrendbe teszi. (a fájlsorrend nem lesz elmentve)
---Rendezni lehet az alábbiak szerint:
név(N) > kiterjesztés(E) > méret(S) > dátum(D) > legkisebb méret(s) > legrégebbi dátum(d) > nincs sorrend
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
BAL-KAR: fájl méret mutatása/elrejtése
---Az alábbiakban adja meg:
byte-ban, Kbyte-ban, Mbyte-ban, byte-ban (könyvtárral együtt),Kbyte-ban (könyvt.e.) és Mbyte-ban (könyvt.együtt) 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Bal (nyíl) + JOBB-KAR:
HACKER MÓD aktiválása/deaktiválása
FIGYELEM: a HACKER MÓD-ot csak saját felelősségre használd ! (KEZDŐKÉNT INKÁBB NE HASZNÁLD!)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
<Szöveg(txt)megjelenítő irányítása>
Fel & Le (nyilak): 	kurzor mozgatása
Fel & Le (Analóg-kar): 	kurzor mozgatása (gyors)
Balra & Jobbra (nyilak):	balra ill. jobbra görgetés (GÖRGETŐ módban)
Balra & Jobbra (Analóg-kar): 	gyors balra ill. jobbra görgetés (GÖRGETŐ módban)
BAL-KAR: Előző oldal
JOBB-KAR:Következő oldal
3SZÖG:	 Tabulátor megállítás változtatása (SORTÖRÉS módban a szöveg újratöltődik)
4SZÖG:	 Bináris megjelenítésre való váltás
KÖR: 	 Váltás GÖRGETŐ ill. SORTÖRÉS mód között
 GÖRGETŐ mód : Balra ill. jobbra tudod görgetni, hogy elolvashasd a szöveget.
 SORTÖRÉS mód : Az összes szöveg a képernyőméretnek megfelelően van tördelve.
 A szöveg újratöltődik a GÖRGETŐ ill. SORTÖRÉS mód között váltás esetén.
start: 	karakterkód megváltoztatása
select: Súgó megjelenítése
X: 	Vissza a Filer-be.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
<Képmegjelenítő irányítása>
Analóg-kar: 	kép görgetése.
KÖR: 		Kép méretének képernyőre való igazítása.
4SZÖG: 		Bináris megjelenítésre való váltás.
start & 3SZÖG:	Aktuális kép háttérként való mentése.
start & KÖR: 	Kép sötétebbé tétele.
X: 		Filer-be való visszalépés (Fő-menü).
JOBB-KAR*: 	Kép kicsinyítése.
BAL-KAR*: 	Kép nagyítása (közelítés).
Jobbra (nyíl)*: következő kép megjelenítése (az aktuális mappában).
Balra (nyíl)*: 	előző kép megjelenítése (az aktuális mappában).
Le & Fel (nyilak)*: Kép forgatása.
* = ez a gombkiosztás megváltoztatható
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
<Bináris szerkesztés menete/leírása>
Fel & Le (nyilak): 	kurzor mozgatása
Fel & Le (Analóg-kar): 	kurzor mozgatása (gyors).
Balra & Jobbra (nyilak):	kurzor mozgatása (csak szerkeszthető fájlnál)
BAL-KAR: Előző oldal
JOBB-KAR: Következő oldal
3SZÖG: váltás bájt/szó/duplaszó mód között
4SZÖG: váltás szöveg/képmegjelenítő között
KÖR: érték növelése +1-gyel (csak szerkeszthető fájlnál).
start: mentés (csak akkor ha változik).
select: Súgó megjelenítése
X: issza a Filer-be.

megjegyzés: A következő fájlok nem szerkeszthetők:
- azok, amelyek mérete nagyon mint a rendelkezésre álló memória (kb. 22MB).
- az archív (.zip, .rar, .iso, .cso) fájlokban lévők.
- flash0/1-ben lévők, kivéve ha át nem váltasz HACKER MÓD-ra.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
<Filer kezelési tipp>
A legtöbb művelet a RAMDISK segítségével zajlik.
A PSP memóriájából 24MB-ot használhat fel a felhasználó, és kb. 20MB-ot használhatunk RAMDISK-nek.
Ezért nem lehet másolni és beilleszteni a túl nagy fájlokat, és mikor nagy méretű fájlok másolódnak a RAMDISK-be a Filer nem tudja végrehajtani az adott műveletet a memória telítettsége miatt.
Vésd észbe, hogy ne hagyj túl sok fájlt a RAMDISK-en, mivel ez csak egy átmeneti tárterület.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
<háttérkép tippek>
- ha a Filer mappájába másolsz egy wallpaper.bmp / wallpaper.jpg / wallpaper.png fájlt (csak, bmp,jpg v. png használható), akkor a Filer egyből felhasználja következő indításakor mint háttér.
- a képnézegetőben nyomj start + 3SZÖG-et a kívánt képre és máris elmenti háttérként.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
<UMD rippelési tanácsok>
Habár az ok nem ismert, de az UMD utolsó 1-3 rekordja nem olvasható a fájlrendszerből. Tehát az iso fájl elkészültekkor az iso 2-6kbyte-tal kisebb mint lehetne. A 3.9-es verziótól fogva a Filer megpróbálja "betömni" azokat a hiányzó rekordokat az alábbiak szerint:
1. A Filer olyan nagy méretbe rippel amekkorába csak lehet.
2. Ellenőrzi a várható méretet úgy, hogy "belenéz" az ISO-fájlba, és ha nagyobb mint a rippelt méret, készít egy a méretkülönbségből adódó adatot (különbségfájl), amit 0-kkal tölt ki.
3. A Filer végigmegy az ISO fájl szerkezetén, és ha vannak olyan fájlok amelyek "elveszett rekordok"-at használnak, akkor bemásolja azokat az adatokat a különbségfájl megfelelő helyére.
4. A Filer végül hozzáfűzi a különbségfájlt a rippelt iso-fájlhoz.

Úgy tűnik, hogy most már jól működik. Küldj hibajelentést nekem, ha ez a funkció nem működik megfelelően, hogy javíthassam.

/személyes megjegyzés: Egyrészt az angol fordítás itt feladta a leckét, másrészt nem baj, ha nem érted miről van szó.. :)./
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

<köszönetlista>
Köszönet djroman-nak a Spanyol fordításért,
Me'Katis-nak a Portugál fordításért,
Experiment1106-nak a Német fordításért,
ipari_kun-nak az Orosz fordításért,
cj92-nek az Olasz fordításért,
soulburn-nek a Lengyel fordításért,
Mizou93-nak (www.psp-ground.net egyik tagja) a Francia fordításért,
FillerUE-nek a Szerb fordításért,
Daniel-nek az Angol fordítás javításáért,
RaiderX-nek a Filer-hez készített ikon-ért,
clint, evilseph, moca, tuw és fergie-nek a hibajelentésekért és tesztelésért, 

- Magyar fordítás: eM82 [pspfilez.team]