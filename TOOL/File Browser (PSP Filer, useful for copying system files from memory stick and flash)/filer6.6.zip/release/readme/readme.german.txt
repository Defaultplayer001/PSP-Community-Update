PSP Filer Version 6.6

/* Please donate (only U.S. $10), if you feel Filer useful.
Paypal & credit card will be accepted. */
http://www.geocities.jp/mediumgauge/

<Wichtig>
Benutzung auf eigene Gefahr.
Dieses Programm kann die PSP zerst�ren oder auch Sch�digen bei falscher Benutzung oder auch
weil Fehler selber im Programm vorliegen.
( fehlermeldung bitte an mediumgauge@yahoo.co.jp, damit diese in zuk�nftigen Versionen behoben werden k�nnen)

- dieses Programm benutzt "shinonome font".
- zum betrachten von PNG Bildern wird libpng1.2.8 + zlib benutzt
- zum betrachten von JPEG Bildern wird jpeg-6b library benutzt

<Handhabung von Filer>

select:
 zeigt die hilfe an
  Kreis: �ndern der Sprache (Japanese, English, Spanish, Deutsch)
  viereck: speichert die einstellungen


start:
 mit start wechselt ihr das Medium ( MS0: < UMD < flash0: < flash1: < RAMDISK)

digital hoch & runter:
 bewegt den cursor 

analog hoch & runter:
 bewegt den Cursor (schnell)

digital links:
 nimmt die marierung aller files aus dem Ordner zur�ck

digital rechts:
 markiert alle files aus dem aktuellen Ordner

analog links:
 nimmt die markierung zur�ck aus dem aktuellen ordner inklusive aller unterordner

analog rechts:
 markiert alle dateien aus dem aktuellen ordner inklusive unterordner

Viereck:
 markiert die ausgew�hlte Datei

Kreis:
 �ffnet den Ordner
 zeigt Bilder an .jpg .jpeg .bmp .png
 spielt mp3 und wav ab
 alle anderen formate werden anders angezeigt

dreieck: startet das Programm Men�
                     kreis: Chromatic Tuner

                     viereck: memory betrachter
                     hier k�nnt ihr den hauptspeicher sehen, oder VRAM und das scratch pad.
                     wichtig: diese function ben�tigt sehr viel Batterie leistung weil sieh 
                     jeden Frame des Memory speichers liest.PSP nicht ausschalten sollange ihr
                     im memory Betrachter seid.
                      
                     dreieck: schaltet das wallpaper an aus ( wenn ihr eines benutzt)

                     R: UMD RIPPING Filer rippt euch die eingelegte UMD auf euren Memory STick in den Ordner
                        ms0:/iso/folder. wenn ihr keinen iso ordner habt wird einer erstellt.
                        Wenn der Memory Stick voll ist wechselt einfach den stick danach k�nnt ihr dann weiter
                        rippen. wenn ihr dann fertig seid und mehere teile habt die dann heissen 1.. 2.. 3.. usw.
                        dann packt die in einen ordner auf eurem pc - dann benutzt ihr die cat.bat die filer mit
                        dem letzten teil erstellt hat - startet diese und alle teile werden zu einer ISO.
 
                     L: Flash Dumper
                        Filer macht Backups eures Flash1 - Flash0 auf euren Memory Stick.
                        im hacker Mode kann Filer so euren Flash wieder herstellen.
                        wenn ihr den Flash wieder hergestellt habt m�sst ihr zuerst Filer verlassen und die 
                        PSP neustarten ( PSP Bug ) sonst arbeiten die files nicht korrekt.

                     hoch: USB verbindung zum PC
                           wenn ihr Files mit dem PC auswechselt kann es zu lesefehlern kommen also frisch
                           starten dann d�rfte alles ok sein .

                     rechts: �ndert die farben
                             hier k�nnt ihr die farben �ndern und mit kreis dann speichern.

                     kreuz: datei operationen

                     Kreis: kopiere dateien
                            markierte dateien: kopiert alle markierten dateien in die RAMDISK
                            unmarkierte datei: kopiert die datei in die RAMDISK

                     quadrat: l�sche dateien
                              markierte dateien: l�scht alle markierten dateien
                            unmarkierte dateien: l�scht die eine datei
                              auf Ordner       : l�scht den gesamten Ordner mit allen dateien und auch Unterordner

                     dreieck: dateien einf�gen
                              f�ge alle dateien aus der RAMDISK in den aktuellen ordner ein

                     links: bewege alle dateien der RAMDISK in den aktuellen ordner

                     R: Datei umbenennen
                        umbenennen der aktuellen datei oder dem Ordner.

                     L: erstelle neuen Ordner
                        
                     hoch: zeige info
                          im root verzeichnis:
                             zeige ger�te info und �berpr�fe cluster struktur
                             dr�cke kreis f�r detaillierte info.
                          bei einer datei oder ordner:
                              zeige datei ordner info an und editiere attribute und timestamps.
                              im Hacker Mode k�nnt ihr auch flash0: flash1: dateien editieren.

                     rechts: verschiebe alle markierten dateien in den aktuellen ordner
                             ihr k�nnt hier dateien verschieben ohne vorher die RAMDISK zu benutzen.
                             wichtig: was hier schief gehen kann ist wenn im Zielorner nicht mehr genug
                             platz vorhanden ist dann kann es probs geben.

                     runter: kopiere alle markierten dateien in aktuellen ordner
                             kopieren k�nnt ihr auch hier ohne die RAMDISK zu benutzen.

R: sortiere dateien im aktuellen ordner ( die sortierung wird nicht gespeichert )
   die sortierung bietet folgende m�glichkeiten:
                                                nach Name(N)  nach Endung (E) nach gr�sse (S) nach datum (D)
                                                die kleinste gr�sse (s) nach �ltestem datum (d) nicht sortiert

R + Links:
              aktiviert den Hacker Mode
              WARNUNG: Die benutzung ist auf eigene Gefahr !!!!!

<text viewer controls/how to
Hoch & Runter : Bewegt den  cursor.
Analog Hoch & Runter : Bewegt den Cursor (schneller).
Links & Rechts: scrolls links & rechts (funktioniert im FLAT mode).
analog links & rechts: schnelles scrollen links & rechts (funktioniert im FLAT mode).
LR: (L) l�d die vorherige Seite (R) l�d die n�chste Seite.
Dreieck: wechselt tab stop 4/8 (der text wird wieder geladen im BEND mode).
Viereck: wechselt zum  binary editor.
Kreis: wechselt zwischen FLAT mode / BEND mode.
 FLAT mode : ihr k�nnt nach links & rechts scrollen zum text lesen.
 BEND mode : der ganze text wird auf die Bilschirmgr�sse angepasst.
 der text wird neu geladen wenn ihr zwischen BEND mode & FLAT mode wechselt.
start: change encoding
select: Zeigt die Hilfe
Kreuz(x): Zur�ck zu Filer.


<Bild Betrachter>

hoch & runter: bewegt den cursor
analog hoch & runter: bewegt den cursor (schnell)
links rechts:scrollt links und rechts (arbeitet im flat modus)
analog links & rechts:scrollt links und rechts (im flat modus)
L R: bl�ttert ganze seiten
dreieck: change tab stop 4/8 (text wird neugeladen wenn der bend modus ist )
quadrat: gehe zum Binary Betrachter
kreis: wechselt zwischen FLAT modus / BEND modus
       Flat modus: ihr k�nnt nach links oder rechts scrollen um text zu lesen
       BEND modus: der ganze text wird auf bildschirmgr�sse ska�iert
                   der text wird neu geladen wenn gewechselt wurde.
Kreuz: zur�ck zu Filer

<Binary Betrachter>

hoch & runter: bewegt den cursor
analog hoch und runter: bewegt den cursor (schnell)
L R : bl�ttert die seiten
quadrat: zur�ck zum Text/Bild Betrachter
Kreuz: zur�ck zu Filer

<Bildbetrachter>

analog: scrolle im bild
R: verkleinere das bild
L: vergr�ssere das Bild
kreis: �ndere die bildgr�sse auf bildschirmgr�sse
quadrat: gehe zum Binary Betrachter
start + dreieck: speichere aktuelles bild als wallpaper
digital rechts: gehe zum n�chsten bild im aktuellen ordner
digital links: gehe zum vorherigen bild im aktuellen ordner
Kreuz: zur�ck zu Filer

<Binary Editor Funktionen>
Hoch und Runter bewegt den Cursor
Analog Hoch und Runter bewegt den Cursor (schneller)
links & Rechts bewegt den Cursor (nur bei editierbaren Files).
LR: (L) l�d die vorherige Seite (R) l�d die n�chste Seite.
Dreieck: �ndert byte/word/longword mode.
Viereck: wechselt zum text/picture view
Kreis: �ndert Wert +1 (nur bei editierbaren Files).
start: Speichert (nur wenn ver�ndert).
select: zeigt die Hilfe
X: Zur�ck zu Filer.

note:Folgende Dateien k�nnen nicht editiert werden .
- die dateigr�sse ist gr�sser als der Memory Speicher  (also 22MB).
-  dateien in folgenden  archiven (.zip, .rar, .iso, .cso) Dateien.
-  in flash0/flash1 m�sst ihr den  HACKER MODE verwenden .

< Datei Bearbeitungs Hinweise>

Die meisten sachen kopiert ihr zuerst auf die RAMDISK wenn ihr im Flash zum Beispiel
sachen �ndern wollt.
Die PSP hat 24MB f�r den benutzer zur verf�gung, und wir k�nnen ca. 20 MB mit der RAMDISK
nutzen, deswegen k�nnen wir dateien die gr�sser sind nicht kopieren und einf�gen also wenn ihr
viele sachen in der RAMDISK lasst wird die gr�sse immer kleiner deswegen am besten wenn ihr fertig
seid und weiter arbeiten wollt immer wieder die RAMDISK l�schen. Die RAMDISK ist nur ein TEMP 
verzeichniss beim ausschalten werden die dateien gel�scht.

<wallpaper tips>

wenn ihr ein hintergrundbild haben wollt k�nnt ihr auch einfach ein Bild nehmen und es in wallpaper.png
oder wallpaper.jpg oder wallpaper.bmp benennen und es in den Filer ordner kopieren wenn filer jetzt
gestartet wird erkennt er es und l�d es als Hintergrund Bild.
Oder ihr sucht das bild mit Filer selber das ihr haben wollt bringt es auf die richtige gr�sse und 
dr�ckt dann Start + Dreieck.

So das war jetzt mal ein kleiner Versuch von mir die wichtigsten Funktionen ein wenig ins deutsche
zu �bersetzen ist mir bei allen sachen nicht so gut gelungen, aber f�r viele wahrscheinlich doch 
deutlicher verst�ndlich als in einer anderen sprache. 

Experiment1106

<thanks>
Thanks djroman to translate into Spanish.
Thanks Me'Katis to translate into Portguese.
Thanks Experiment1106 to translate into German.
Thanks ikari_kun to translate into Russian.
Thanks cj92 to translate into Italian.
Thanks soulburn to translate into Polish.
Thanks Mizou93, a member of www.psp-ground.net, to translate into French.
Thanks FillerUE to translate into Serbian.
Thanks eM82 to translate into Hungarian.
Thanks SaCReD VoIcE to translate into Bulgarian.
Thanks michael saant to translate into Greek.
Thanks RaiderX to make icon.
Thanks clint, evilseph, moca, tuw and fergie to help debugging.
Thanks Daniel to correct English.
