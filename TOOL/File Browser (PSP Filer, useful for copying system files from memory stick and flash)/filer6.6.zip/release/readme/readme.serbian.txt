PSP Filer Verzija 6.6

/* Please donate (only U.S. $10), if you feel Filer useful.
Paypal & credit card will be accepted. */
http://www.geocities.jp/mediumgauge/

<UPOZORENJE!>
Koristite na SOPSTVENI RIZIK!!!

<ODRICANJE>
Ovaj softver moze prouzrokovati ozbiljna ostecenja vasem PSP-u usled manjka vaseg znanja ili bagova koje Filer moze imati.
Autor psp filer-a ne moze biti smatran odgovornim za bilo kakvo nastalo ostecenje.
Ako zablokirate (brick) vas psp greska je iskljucivo vasa.
(prijavite greske (bagove) na mediumgauge@yahoo.co.jp, i mozda ce biti ispravljeni u nekoj od sledecih verzija)

- ovaj program koristi "shinonome font".
- za pregled PNG slika, libpng1.2.8 + zlib se koristi.
- za pregled JPEG slika, jpeg-6b library se koristi.

<Filer kontrole/kako da>
select:prikazi pomoc
 krug: promeni jezik (Japanski, Engleski, Spanski, Portugalski, Nemacki, Ruski, Italijanski, Poljski, Francuski, Srpski, Madjarski)
 kvadrat: sacuvaj podesavanja

start:
 predji na sledeci uredjaj. (MS0 > UMD > flash0 > flash1 > RAMDISK)

digitalno gore & dole:
 pomeranje kursora

analogno  gore & dole:
 pomeranje kursora (brzo)

digitalno levo:
 deselektuj sve fajlove u direktorijumu.

digitalno desno:
 selektuj sve fajlove u direktorijumu.

analogno levo:
 ispisi ime fajlova krace.

analogno desno:
 ispisi ime fajlova duze.

kvadrat:
 oznaci fajl.

krug:
 produzi/prosiri na direktorijum.
 vidi sliku na .jpg / .jpeg / .bmp / .png.
 pusti zvuk na .wav / .mp3.
 prikazi ostale fajlove.

trougao: programski meni
   krug: stimer instrumenata & metronom
   kvadrat: pregled memorije
    mozete videti glavnu memoriju, VRAM i beleznicu.
    beleska: za ovu opciju vam treba baterija jer iscitava memoriju na svaki frejm.
     nemojte ostavljati PSP sa ukljucenim pregledom memorije.
   trougao: ukljuci prikaz pozadine (ako se pozadina koristi)
   R: Cuvanje sa UMD uredjaja
    Filer cuva UMD image u ms0:/iso/ direktorijumu.
    ako /iso/ direktorijum ne postoji, bice napravljen.
    ako je MS Duo pun, zamenite MS Duo, Filer ce nastaviti sa snimanjem.
    i kada je sve zavrseno, skupite sve razdvojene fajlove (imenovane *.1, *.2, ...etc) u jedan direktorijum na PC,     koristite "cat.bat" koji je napravljen u zadnjem direktorijumu, spojice se u jedan .ISO fajl.
   L: odrzavanje flash memorije
    Filer bekapuje flash0/flash1 fajlove na MS Duo.
    i, kada ste u HACKER REZIMU, Filer moze povratiti flash0/flash1 fajlove sa MS Duo.
    Mozete koristiti ovu opciju za oporavak flash0/flash1 fajlova.
    kada je oporavak zavrsen, flash fajl ne odaziva se ispravno (zbog greske u psp-u), moj savet je da izadjete iz     filer-a i resetujete uredjaj.
 gore: prikaci se putem USB-a
    u ovoj verziji, nakon iskljucenja, Filer ne moze iscitati fajlove izmenjene na PC-u ispravno, zato molimo     ponovo ubacite MS Duo kada Filer to zatrazi.
   desno: promeni podesavanje boje
    mozete promeniti podesavanje boja i mozete sacuvati pritiskajuci krug.
    levo: preuredi XMB ikone
    mozete preurediti XMB ikonice. Pritisnite krug i drzite jednu ikonu, i onda pomerajte na neko drugo mesto     pritiskajuci gore & dole. Sacuvajte izmene pritiskajuci Start.

X: operacije sa fajlovima
   krug: kopiraj/premesti fajlove
     na selektovanim fajlovima: kopiraj/premesti sve selektovane fajlove.
     na neselektovanom fajlu: kopiraj/premesti ovaj fajl.
     na direktorijumu: kopiraj/premesti sve fajlove i poddirektorijume u ovom direktorijumu.
     beleska.1: kada premestate fajlove, vrsi se po principu "kopiraj i izbrisi" pa se samim tim operacija ne                 izvrsava ukoliko nema dovoljno prostora na ciljnom podrucju.
     beleska.2: ne mozete izmeniti flash0/flash1 ukoliko ne aktivirate HACKER REZIM.
   kvadrat: izbrisati fajlove
     na selektovanim fajlovima: izbrisi sve selektovane fajlove.
     na neselektovanom fajlu: izbrisi ovaj fajl.
     na direktorijumu: izbrisati sve fajlove i poddirektorijume u ovom direktorijumu.
   R: promeniti ime fajlu / direktorijumu.
   L: napraviti novi direktorijum.
   gore: prikazi / izmeni informacije
    na glavnom (root) direktorijumu MS / flash0 / flash1:
     prikazi info uredjaja i proveriti klaster strukturu.
     pritisnite krug za detaljne informacije.
    na glavnom direktorijumu UMD-a:
     prikazi fizicku velicine i opisnu velicinu ISO fajla.
    na glavnom direktorijumu RAMDISK-a:
     prikazuje zauzetost memorije iskoriscenu RAMDISK fajlovima.
    na fajl ili direktorijum:
     prikazuje fajl/direktorijum informacije i menja atribute i datume.
     u HACKER REZIMU mozete cak menjati flash0/flash1 fajlove.
    na fajlu:
     pritiskajuci krug, MD5 fajla ce biti izracunat.

R: uredi fajlove direktorijuma. (uredjenje nece biti sacuvano)
  uredi izmene prema:
    imenu(N) > ekstenziji(E) > velicini(S) > datumu(D) >
    manjoj velicini(s) > starijem datumu(d) > neuredjeno

L: ukljuci mod velicina fajla:
  menja preglednik: ispisi prema bajtima, kilobajtima, megabajtima,
    prema bajtima (sa direktorijumom), kilobajtima (s/d) i megabajtima (s/d)

digitalno levo + R:
  ukljuci HACKER REZIM.
  UPOZORENJE: koristite HACKER REZIM na SVOJU ODGOVORNOST (NE KORISTITE AKO STE NOVI KORISNIK)

<pregled teksta kontrole/kako da>
gore & dole: pomeranje kursora.
analogno gore & dole: pomeranje kursora (brze).
levo & desno: pomeranje levo & desno (radi u FLAT rezimu).
analogno levo & desno: brzo pomeranje levo & desno (radi u FLAT rezimu.)
LR: (L) ucitava prethodnu stranu (R) ucitava sledecu stranu.
trougao: menja tabulacijsko stopiranje (tekst se ponovo ucitava kada je u BEND rezimu).
kvadrat: predji na binarni editor.
krug: ukljuci FLAT / BEND rezim.
 FLAT rezim : mozete pomerati levo & desno da citate tekst.
 BEND rezim : citav tekst je preuredjen da zauzme velicinu ekrana.
 tekst se ponovo ucitava menjanjem iz jednog u drugi rezim.
start: promeni sifrovanje
select: prikazi pomoc
X: povratak u Filer.

<pregled slika kontrole/kako da>
analogno: pomeranje slike.
krug: menjanje velicine slike radi prilagodjavanja velicini ekrana.
kvadrat: prelazak u binarni editor.
start & trougao: sacuvaj sliku kao pozadinsku.
start & krug: napravi sliku tamnijom.
X: povratak u Filer (glavni meni).
R*: smanjuje sliku (odzumiranje).
L*: povecava sliku (zumiranje).
digitalno desno*: prelaz na sledecu sliku (u istom direktorijumu).
digitalno left*: prelaz na prethodnu sliku (u istom direktorijumu).
digitalno gore & dole*: rotira sliku.
* = korisnik moze dodeliti funkcije tasterima.

<binarni editor kontrole/kako da>
gore & dole: pomeranje kursora.
analogno gore & dole: pomeranje kursora (brze).
levo & desno: pomeranje kursora (fajl koji moze biti editovan).
LR: (L) ucitava prethodnu stranicu (R) ucitava sledecu stranicu.
trougao: promeni na bajt/rec/duga rec rezim.
kvadrat: pomeri u tekst/slika pregled.
krug: promeni vrednost +1 (fajl koji moze biti editovan).
start: sacuvaj (usled izmene jedino).
select: prikazi pomoc
X: povratak u Filer.

beleska:Sledeci fajlovi ne mogu biti editovani.
- velicina fajla je veca od memorije (oko 22MB).
- povezani u arhivi (.zip, .rar, .iso, .cso) fajl.
- smesteni u flash0/flash1 osim ako je HACKER REZIM ukljucen.

<Filer operacijski saveti>
Vecina operacija se izvrsava putem RAMDISK-a.
PSP ima 24MB za korisnika, a mi mozemo koristiti oko 20MB za RAMDISK.
Zbog toga ne mozemo kopirati/prilepiti fajlove koji su preveliki, a kada su veliki fajlovi kopirani u RAMDISK, Filer ne moze da odradi proces ispravno zbog nedostatka memorije.
Zapamtite da ne ostavite puno fajlova na RAMDISK-u - koriscen je iskljucivo kao privremeno mesto za skladistenje i bolje da izbrisete fajlove odmah posle izvrsene operacije.

<Saveti za pozadinsku sliku>
- ako stavite wallpaper.bmp / wallpaper.jpg / wallpaper.png,(koristite jedino bmp,jpg & png) Filer ih automatski pronalazi kada se pokrene i koristi sliku kao pozadinu.
- u pregledu slika, pritisnite start & trougao, na slici vaseg izbora i bice sacuvana kao "wallpaper.bmp" i registrovana kao pozadinska.

<UMD snimanje saveti>
Iako razlog nije 100% poznat, zadnjih 1-3 snimka UMD-a ne mogu biti iscitani. Usled toga, snimajuci UMD, ISO fajl je 2k-6k (1rekord = 2bajta) manji nego sto bi trebao biti. Od verzije 3.9, Filer pokusava da popuni "izgubljene rekorde" sledecom sekvencom:

1. Filer snima veliko koliko je moguce.
2. Filer proverava ocekivanu velicinu fajla pregledajuci ISO fajl, i ako je veci od snimljenog popunjava razliku u velicini sa 0.
3. Filer pretrazuje ISO strukturu, i ako postoje "izgubljeni rekordi", kopira te podatke na prava mesta u razlici podataka.
4. Filer dodaje razliku podataka u snimljenom ISO fajlu.

Izgleda da radi dobro sada. Obavestite o eventualnim greskama usled snimanja - ispravicemo.

<Hvala>
Hvala djroman za prevod na Spanski.
Hvala Me'Katis za prevod na Portugalski.
Hvala Experiment1106 za prevod na Nemacki.
Hvala ikari_kun za prevod na Ruski.
Hvala cj92 za prevod na Italijanski.
Hvala soulburn za prevod na Poljski.
Hvala Mizou93, clan www.psp-ground.net, za prevod na Francuski.
Hvala FillerUE za prevod na Srpski.
Hvala eM82 za prevod na Madjarski.
Hvala SaCReD VoIcE za prevod na Bugarski.
Hvala michael saant za prevod na Grcki.
Hvala RaiderX na ikonama.
Hvala clint, evilseph, moca, tuw i fergie na pomoci ispravljanja gresaka.
Hvala Daniel za lekturu Engleskog.