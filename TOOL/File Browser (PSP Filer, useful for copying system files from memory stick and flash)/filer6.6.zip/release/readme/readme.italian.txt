PSP Filer version 6.6

/* Please donate (only U.S. $10), if you feel Filer useful.
Paypal & credit card will be accepted. */
http://www.geocities.jp/mediumgauge/

<ATTENZIONE!>
Utilizzalo a tuo rischio e pericolo!!!.

<DISCLAIMER>
Questo software pu� causare gravi danni alla tua PSP, magari dovuti a qualche bug del Filer.
Il coder non � responsabile di nessun danno procurato alla vostra console.
(riportate i bug a mediumgauge@yahoo.co.jp, e potrebbero essere fixati nelle prossime versioni)

- questo software usa "shinonome font".
- per visualizzare le immagini PNG, viene utilizzato libpng1.2.8 + zlib.
- per visualizzare le immagini JPEG, viene utilizzato jpeg-6b library.

<Filer controls/how to>
select:mostra aiuto
 cerchio: cambia lingua (Giapponese, Inglese, Spagnolo, Portoghese, Tedesco)
 quadrato: salva impostazioni

start:
 spostati nel dispositivo successivo. (MS0 > UMD > flash0 > flash1 > RAMDISK)

digital su & giu:
 muovi il cursore

analog su & giu:
 muovi il cursore (velocemente)

digital sinistra:
 deseleziona tutti i files in quella cartella.

digital destra:
 seleziona tutti i files in quella cartella.

analog sinistra:
 deseleziona tutti i files in quella cartellae nelle sue sottocartelle.

analog destra:
 seleziona tutti i files in quella cartellae nelle sue sottocartelle.

quadrato:
 seleziona quel file.

cerchio:
 estendi/richiudi la cartella.
 visualizza immagini se sono .jpg / .jpeg / .bmp / .png.
 ascolta brani se sono .wav / .mp3.
 mostra file.

triangolo: menu dell'applicazione
   cerchio: sintonizzatore strumenti
   quadrato: visualizzatore memoria
    puoi vedere memory, VRAM, e scratch pad.
    nota: questa funzionalit� sfrutta molto la batteria.
     non lasciate la psp ferma nel visualizzatore memoria.
   triangolo: abilita  la mostra degli sfondi
   R: rip dell'UMD
    Il Filer rippa un immagine del tuo UMD in ms0:/iso/.
    se la cartella /iso/ non esiste, verr� creata.
    se la MS � piena, cambia MS, e il Filer continuer� con il rip.
    e alla fine del rip, spostate i file ottenuti (chiamati *.1, *.2, ...etc) in una cartella sul PC, e avviate "cat.bat", e vi creer� il file ISO.
   L: mantenimento della memoria flash
    Il Filer pu� fare i backup delle  flash0/flash1 nella MS.
    e, nella modalit� HACKER, il Filer pu� ripristinare le flash0/flash1 dalla MS.
    Puoi usare quest� funzionalit� per ripristinare le flash0/flash1.
    dopo il ripristino, � consigliato riavviare il programma.
   su: abilita l'USB
    dopo aver disconnesso � consigliato riavviare il programma.
   destra: cambia impostazioni sul colore
    puoi cambiare le impostazioni sul colore e salvarle premendo cerchio.

croce: operazioni sul file
   cerchio: copia/sposta file
     su file selezionati: copia/sposta tutti i file selezionati.
     su file non selezionati: copia/sposta quel file.
     su cartelle: copia/sposta tutti i file e sottocartelle.
     nota.1: quando sposti un file in pratica viene copiato e eliminato.
     nota.2: non puoi modificare le flash0/flash1 se non attivi la modalit� HACKER.
   quadrato: elimina file
     su file selezionati: elimina tutti i file selezionati.
     su file non selezionati: elimina quel file.
     su cartelle: elimina tutti i file e sottocartelle.
   R: rinomina il file o la cartella.
   L: crea una nuova cartella
   su: mostra / modifica le informazione nella root della memoria.
     mostra informazioni sul dispositivo e controlla la struttura dei cluster.
     premi cerchio per visuliazzre informazioni dettagliate.
     in file o cartelle:
     mostra le informazioni del file o cartella e modifica gli attributi.
     quando sei nella modalit� HACKER modifica i file delle flash.
     in file:
       premendo cerchio, verr� calcolato l'MD5 del file.

R: sort files on current folder. (the sorted file order will not be saved)
  order changes following:
    by name(N) > by ext(E) > by size(S) > by date(D) >
    by smaller size(s) > by older date(d) > not sorted

digital sinistra + R:
  abilita modalit� HACKER.
  ATTENZIONE: usa la modalit� HACKER a tuo rischio e pericolo.

<text viewer controls/how to>
su & giu: muovi il cursore.
analog su & giu: muovi il cursore (velocemente).
sinistra & destra: scorri a sinistra e a destra.
analog sinistra & destra: scorri a sinistra e a destra (velocemente).
LR: (L) pagina precedente (R) pagina successiva.
triangolo: change tab stop 4/8 (text is reloaded when in BEND mode).
quadrato: spostati nel visualizzatore binario.
cerchio: abilita FLAT mode / BEND mode.
 FLAT mode : puoi scorrere a dx e sxper leggere il testo.
 BEND mode : all text is rearanged to fit the screen size.
start: cambia codifica
select: mostra aiuto
croce: ritorna al Filer.

<picture viewer controls/how to>
analog: scorri l'immagine.
cerchio: adatta l'immagine allo schermo.
quadrato: spostati nel visualizzatore binario.
start & triangolo: salva questa immagine come sfondo.
start & quadrato: rendi l'immagine pi� scura.
croce: ritorna al Filer.
R*: zoom out.
L*: zoom in.
digital destra*: immagine successiva.
digital sinistra*: immagine precedente.
digital su & giu*: ruota l'immagine.
* = l'utente pu� personalizzare questi tasti.

<filer operation tips>
la maggior parte delle operatione � fatta via RAMDISK.
La PSP ha 24 MB per l'user, e noi possiamo usarne 20MB.
Ecco perch� non possiamo copiare file troppo grandi.

<wallpaper tips>
- se metti altri wallpaper.bmp / wallpaper.jpg / wallpaper.png,(usa solo bmp,jpg & png) il Filer riconoscer� l'immagine quando si avvia e user� l'immagine come sfondo.
- nel visualizzatore immagini, premi start e triangolo, nell'immagine scelta da te e verr� salvata come wallpaper.bmp e memorizzata come sfondo.

<ringraziamenti>
Grazie djroman per la traduzione in Spagnolo.
Grazie Me'Katis per la traduzione in Portghese.
Grazie Experiment1106 per la traduzione in Tedesco.
Grazie ikari_kun per la traduzione in Russo.
Grazie RaiderX per le icone.
Grazie clint, evilseph, moca, tuw and fergie per l'aiuto nel debug.
Grazie Daniel per la correzione dell'Inglese.
