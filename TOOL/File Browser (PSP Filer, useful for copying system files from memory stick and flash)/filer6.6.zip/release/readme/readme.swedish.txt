﻿PSP Filer version 6.6

/* Donera (bara U.S. $10), om du tycker Filer är användbart.
Paypal & kreditkort accepteras. */
http://www.geocities.jp/mediumgauge/

<VARNING!>
Används på EGEN RISK!!!.

<INFORMATION>
Denna mjukvara kan medföra vissa problem med din PSP genom din kunnighet eller buggar som Filer kan ha.
Skaparen av PSP Filer kan inte ta ansvar om något händer med din PSP.
Om du brickar din PSP är det ditt eget ansvar.
(rapportera buggar till mediumgauge@yahoo.co.jp, så kommer det att fixas i nästa version)

- denna mjukvara använder "shinonome font".
- för att visa PNG picture, används libpng1.2.8 + zlib.
- för att visa JPEG picture, används jpeg-6b.

<Filer kontroller/hur man gör>
select:visa hjälp
 cirkel: ändra språk (Japanese, English, Spanish, Portguese, German, Russian, Italy, Polish, French, Seriban, Hungarian, Svenska)
 tekant: save settings

start:
 flytta till nästa enhet. (MS0 > UMD > flash0 > flash1 > RAMDISK)

digital upp & ner:
 flytta pekare

analog upp & ner:
 flytta pekare(snabbt)

digital vänster + cirkel:
 flytta till föregående mapp.

digital vänster + start:
 spara denna mapp som standard. (visar mappen vid uppstart)

digital vänster + triangel:
 flytta till standardmapp.

digital höger:
 markera/avmarkera alla nuvarande mappens filer.

analog vänster:
 gör filnamnet kortare.

analog höger:
 gör filnamnet längre.

fyrkant:
 markera nuvarande fil.

cirkel:
 kollapsa/expndera mappen.
 visa bilder som har .jpg / .jpeg / .bmp / .png.
 spela upp .wav / .mp3.
 visa fil påå annat.

triangel: program meny
   cirkel: instrument tuner & metronom
   fyrkant: minnesvisare
    du kan se huvudminne, VRAM, och scratch pad.
    notera: denna funktion behöver batteri för att den läser minne på varje frame.
     lämna inte din PSP när den visar minnesvisaren.
   triangel: visar bakgrundsbild (om du använder det)
   R: UMD rippning
    Filer rippar en UMD bildfil (.iso fil) till ms0:/iso/ mappen.
    om /iso/ mappen inte existerar kommer den att skapas.
    om ditt MS Duo är fullt, ändra MS Duo, och Filer kommer fortsätta rippningen.
    aoch efter att det är klart, spara alla delade filer (namngivna *.1, *.2, ...mm) till en mapp på din PC, använd "cat.bat" som är skapat i den sista delmappen, så kommer du få en komplett ISO fil.
   L: underhåll flashminnet
    Filer säkerhetskopierar flash0/flash1 bilderfiler till ditt MS Duo.
    och, när du använder HACKER LÄGET, kan FIler återställa flash0/flash1 bildfilen från ditt MS Duo.
    Du kan använda denna funktionen för att återställa flash0/flash1 bldfiler.
    efter att återställningen är klar, kommer flash bildfilerna inte bli korrekta filer (på grund av en bugg i PSP:n), Jag rekomenderar att avsluta Filer och starta om igen.
   upp: anslut USB
    i denna version, efter frånkoppling, kan Filer inte läsa ändrade filer från en PC korrekt, så, ta ut och sedan sätt tillbaka ditt MS Duo när Filer meddelar.
   höger: ändra färginställningar
    du kan ändra färginställningarna och spara dem genom att trycka på cirkel.
   vänster: byt plats på XMB ikoner XMB iconer
    du kan byt plats på XMB ikoner. Tryck på cirkel och håll en ikob, och flytta den till ett ställe och placera den genom att trycka på upp & ner. spara dem genom att trycka ppå start.
   ner: modifiera CPU hastighet
    du kan ändra din CPU hastighet.

kryss: filoperation
   cirkel: kopiera/flytta filer
     på en markerad fil: kopera/flytta alla markerade filer.
     på en omarkerad fil: kopiera/flytta denna fil.
     på en mapp: kopiera/flytta alla filer ¥ undermappar i denna mapp.
     notera.1: när du flyttar filer använder det 'kopiera & ta bort' före den operationen kan inte slutföras om den inte finns tillräckligt fritt utrymme på nuvarande enhet.
     notera.2: du kan inte modifiera flash0/flash1 om du inte aktiverar HACKER LÄGET.
   fyrkant: ta bort filer
     på en markerad fil: ta bort alla markerade filer.
     på en omarkerad fil: ta bort denna fil.
     på en mapp: ta bort alla filer & undermappar i denna mapp.
   R: byt namn på nuvarande fil / mapp.
   L: skapa en ny mapp
   upp: visa / ändra information
    på root mappen av MS / flash0 / flash1:
     visa enhetsinfo och kolla kluster strukturen.
     tryck på cirkel för att visa detaljerad information.
    på root mappen av en UMD:
     visar ''phygical'' storkel & ''described'' storlek i ISO.
    på root mappen av RAMDISK:
     visar minnesanvändning som används av RAMDISK filer.
    på en fil eller en mapp:
     visar fil/mapp information eller ändrar attributer & tidsstämplar.
     när du är i HACKER LÄGET kan du även ändra flash0/flash1 filer.
    på en fil:
     tyyck på cirkel, MD5 av filen kommer att kalkyleras.

R: sortera filer i nuvarande mapp. (den sorterade filordningen kommer inte sparas)
  sorteringsändringar följande:
    med name(N) > med ext(E) > med storlek(S) > med datum(D) >
    med mindre storlek(ar) > med äldre datum > ej sorterat

L: filstorleks läge:
  ändrar läge :sortera efter byte, Kbyte, Mbyte,
    med byte (med mapp), Kbyte (w/d) och Mbyte (w/d)

digital vänster + R:
  aktivera HACKER LÄGET.
  VARNING: använd HACKER LÄGET på din EGEN RISK (ANVÄND INTE OM DU ÄR EN NOOB).

<textvisare kontroller/hur>
upp & ner: flytta pekaren.
analog upp & ner: flyttar pekaren (snabbare).
vänster & höger: skrollar vänster & höger (fungerar på FLAT läget).
analog vänster & höger: snabb skrollning vänster & höger (fungerar på FLAT läget).
LR: (L) Laddar föregående sida (R) laddar nästa sida.
triangel: ändra tabb stopp 4/8 (text är återladdan om du använder BEND läget).
fyrkant: flyttar till binär-redigerarer.
cirkel: aktivera FLAT läget / BEND läget.
 FLAT läge : du kan skrolla vänster & höger för att läsa text.
 BEND läge : all text är fixerad att fylla skärmstorleken.
 text är fixerad nr du bytar mellan BEND läget & FLAT läget.
start: ändra kodning
select: visa hjälp
kryss: återgå till Filer.

<bildvisnings kontroller/hur>
analog: skrolla bild.
cirkel: ändrar bildens storlek till att passa skärmen.
fyrkant: ändrar till binär-redigerare.
start & triangel: sparar nuvarande bild som bakgrund.
start & cirkel: gör bilden mörkare.
start & digital vänster, höger, upp och ner: flyttar till mitten av bilden.
kryss: återgår till Filer (huvudmeny).
R*: förminskar bilden (zooma ut).
L*: förstorar bilden (zooma in).
digital höger*: flyttar till nästa bild (i nuvarande mapp).
digital vänster*: fyttar till föregående bild (i nuvarande mapp).
digital upp & ner*: roterar bilden.
* = användaren kan ändra dessa kontroller.

<binär-redigerare kontroller/hur>
upp & ner: flyttar pekaren.
analog upp & ner: flyttar pekaren (snabbare).
vänster & höger: flyttar pekaren (bara redigerbara filer).
LR: (L) laddar föregående sida (R) laddar nästa sida.
triangel: ändra byte/ord/långt ord läge.
fyrkant: flyttar till text/bild-visare.
cirkel: modifiera världe +1 (bara redigerbara filer).
start: spara (bara om ändrat).
select: visa hjälp
kryss: återgå till Filer.

notera:Följande filer kan inte redigeras.
- filen är större än minnet (ungefär 22MB).
- finns i ett arkiv (.zip, .rar, .iso, .cso).
- placerat i flash0/flash1 om du inte aktiverar HACKER LÄGET.

<filer operations tips>
most of operation is done via RAMDISK.
PSP has 24MB memory for user, and we can use about 20MB for RAMDISK.
That's why we cannot copy/paste files that are to large , and when large files have been copied/pasted in the RAMDISK, Filer cannot do its operations properly because of a shortage of memory.
remember not to leave to many files on the RAMDISK - it is only used as a temporary storage area and you better remove the files soon after doing the intended operation.

<bakgrunds tips>
- if you put either  wallpaper.bmp / wallpaper.jpg / wallpaper.png,(only use bmp,jpg & png) Filer detects the picture when it next starts up, and uses the picture as the wallpaper.
- since version 5.3, you can put filer / text / binary [.bmp/.jpg/.png] and Filer changes background as mode changes.
- in picture viewer, push start & triangle, on the picture of your choice and it will be saved as "wallpaper.bmp" and registered as a wallpaper.

<UMD rippnings tips>
Though the reason is not clear now, the last 1-3 record of UMD cannot be read from filesystem. So, doing ripping operation, the iso file is 2k-6k (1record = 2kbytes) smaller than it should be. Since version 3.9, Filer try to fill those "lost tail records" by following sequence:

1. Filer rips as large as possible.
2. Filer checks expected size by peeking ISO file, and if it is larger than ripped size, create a differential size data which is filled with 0.
3. Filer searches ISO file structure, and if there are files which uses "lost tail records", copy those data into right place of the differential data.
4. Filer appends the differential data to the ripped ISO file.

It seems to work fine now. Give me reports if the feature does not work well - to fix it.

<tack>
Tack djroman för att ha översatt till Spanish.
Tack Me'Katis för att ha översatt till Portguese.
Tack Experiment1106 för att ha översatt till German.
Tack ikari_kun för att ha översatt till Russian.
Tack cj92 för att ha översatt till Italian.
Tack soulburn för att ha översatt till Polish.
Tack Mizou93, en medlem på www.psp-ground.net, för att ha översatt till French.
Tack FillerUE för att ha översatt till Serbian.
Tack eM82 för att ha översatt till Hungarian.
Tack SaCReD VoIcE för att ha översatt till Bulgarian.
Tack michael saant för att ha översatt till Greek.
Tack RaiderX för att ha skapat ikonen.
Tack clint, evilseph, moca, tuw och fergie för hjälp med att hitta buggar.
Tack Daniel för korrekt Engelska.
